import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function DepDelete(){

    const{d_id}=useParams();
    const[did,setDid]=useState(d_id);
    const navigate=useNavigate();

    const Delete=()=>{
        fetch("http://localhost/mallapi/Department.py",{
            method:"Delete",
            body:JSON.stringify(
                {
                    dept_id:did,
                   
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/DepShow")
            
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Department Delete</h1>
            Department Id<input type="text" className="form-control" placeholder="Department Id"  disabled={true}  onChange={(e)=>setDid(e.target.value)}value={did}/><br/>
            <input type="text" value="Delete" className="btn btn-danger" onClick={Delete}/>
        </div>
    )
}
export default DepDelete;