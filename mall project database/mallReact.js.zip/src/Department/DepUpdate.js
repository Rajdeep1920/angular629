import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";


function DepUpdate(){
    const{d_id,d_nm}=useParams();
    const[did,setDid]=useState(d_id);
    const[dnm,setDnm]=useState(d_nm);
    const navigate=useNavigate();
    const Update=()=>{
        fetch("http://localhost/mallapi/Department.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    dept_id:did,
                    dept_nm:dnm
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/DepShow")
            
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Department Update</h1>
            Department Id<input type="text" placeholder="Department Id" disabled={true} className="form-control" onChange={(e)=>setDid(e.target.value)}value={did}/><br/>
            Department Name<input type="text" placeholder="Department Name" className="form-control" onChange={(e)=>setDnm(e.target.value)}value={dnm}/><br/>
            <input type="button" value="Update" className="btn btn-warning"  onClick={Update}/>
        </div>
    )
}
export default DepUpdate;