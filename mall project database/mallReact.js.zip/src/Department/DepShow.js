import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function DepShow(){
  const[all,setAll]=useState([]);
  const navigate=useNavigate();
    const Show=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])
            const NewData=()=>{
                navigate("/DepInsert")
            }
    return(
        <div className="text-center">
            <h1>Show All Department Data</h1>
            <input type="button" value="Add New Data" className="btn btn-success" onClick={NewData}/><br/><br/>
            <table className="table text-center table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Department Id</th>
                    <th>Department Name</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.dept_id}</td>
                        <td>{data.dept_nm}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/DepUpdate/${data.dept_id}/${data.dept_nm}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/DepDelete/${data.dept_id}`}>Delete</Link>
                        </td>
                    </tr>
                    )
                }
            </table>
        </div>
    )
}
export default DepShow;