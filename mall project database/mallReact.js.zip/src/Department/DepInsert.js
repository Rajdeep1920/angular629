import { useState } from "react"
import { useNavigate } from "react-router-dom";

function DepInsert(){
    const [dnm,setDnm]=useState();
    const navigate=useNavigate();
    

    const Insert=()=>{
        fetch("http://localhost/mallapi/Department.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    
                    'dept_nm':dnm
                }
            ),
            headers:{"content-type": "application/json;charset=UTF-8"}
        }
        ).then(response=>{
            response.json()
            navigate("/DepShow")

           
        }).then(json=>{
            console.log(json)
        })
        
    }
    return(
        <div className="text-center">
            <h1>Department Insert</h1>

            Department Name<input type="text" className="form-control" placeholder="Department Name" onChange={(e)=>setDnm(e.target.value)}/><br/>
            <input type="button" className="btn btn-success" value="Insert" onClick={Insert}/>
        </div>
    )
}
export default DepInsert;