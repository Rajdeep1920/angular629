import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function MasterInsert(){

    const[cid,setCid]=useState();
    const[eid,setEid]=useState();
    const[sdate,setSdate]=useState();
    const[gt,setGt]=useState();
    const[gtot,setGtot]=useState();
    const navigate=useNavigate();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);

    const Insert=()=>{
        fetch("http://localhost/mallapi/Sale_Master.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    
                   
                    counter_id:cid,
                    emp_id:eid,
                    sale_date:sdate,
                    gst:gt,
                    grand_total:gtot
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/MasterShow")
        }).then(json=>{
            console.log(json)
        })

    }

    const EmpShow=()=>{
        fetch("http://localhost/mallapi/Counter.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])

            const Show=()=>{
                fetch("http://localhost/mallapi/Employee.py")
              
                .then((Response) => {
                    if (!Response.ok) {
                        throw new Error("Network response was not ok");
            
                    }
                    return Response.json();
            
                })
                        .then((data) => {
            
                            setCall(data)
                            console.log(data)
                        })
                        .catch((error) => {
                            console.error("there was a problem with the fetch operation", error);
                        });
            }
            useEffect(()=>EmpShow(),[])
         

    return(
        <div className="text-center">
            <h1>Insert Sale Master</h1>
          
            Counter Id<select className="form-control" onChange={(e)=>setCid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.counter_id}>{data.counter_nm}</option>)
                })
            }     
            </select><br/>
            Employee Id<select className="form-control" onChange={(e)=>setEid(e.target.value)}>{
                call.map((data)=>{
                    return(<option value={data.emp_id}>{data.emp_nm}</option>)
                })
            }     
            </select><br/>
            Sale Date<input type="date" className="form-control"  onChange={(e)=>setSdate(e.target.value)}/><br/>
            GST<input type="text" className="form-control" placeholder="GST" onChange={(e)=>setGt(e.target.value)}/><br/>
            Grand Total<input type="text" className="form-control" placeholder="Grand Total" onChange={(e)=>setGtot(e.target.value)}/><br/>
            <input type="button" className="btn btn-success" value="Insert" onClick={Insert}/>
        </div>
    )
}
export default MasterInsert;