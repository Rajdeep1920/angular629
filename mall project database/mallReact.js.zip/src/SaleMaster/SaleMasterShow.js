import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";



function MasterShow(){


    const[all,setAll]=useState([]);
    const navigate=useNavigate();
    

    const Show=()=>{
        fetch("http://localhost/mallapi/Sale_Master.py")

        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });


   
    }
    useEffect(()=>Show(),[])

    const AddNew=()=>{
        navigate("/MasterInsert")
    }

    return(
        <div className="text-center">
            <h1>Sale Master Data</h1>
            <input type=" text" className="btn btn-success" value="Add New Data" onClick={AddNew}/><br/><br/>

            <table className="table table-striped table-hover table-bordered"  border={"2px"}>
                <tr>
                    <th>Sale Id</th>
                    <th>Counter Id</th>
                    <th>Employee Id</th>
                    <th>Sale Date</th>
                    <th>GST</th>
                    <th>Grand Total</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.sale_id}</td>
                        <td>{data.counter_id}</td>
                        <td>{data.emp_id}</td>
                        <td>{data.sale_date}</td>
                        <td>{data.gst}</td>
                        <td>{data.grand_total}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/MasterUpdate/${data.sale_id}/${data.counter_id}/${data.emp_id}/${data.sale_date}/${data.gst}/${data.grand_total}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/MasterDelete/${data.sale_id}`}>Delete</Link>
                        </td>
                    </tr>
                    )
                }


            </table>

        </div>
    )
}
export default MasterShow;