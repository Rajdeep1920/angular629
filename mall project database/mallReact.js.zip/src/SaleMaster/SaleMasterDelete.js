import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";


function MasterDelete(){

   const{sale}=useParams();
    const[sid,setSid]=useState(sale);
    const navigate=useNavigate();
    
    const Delete=()=>{

        fetch("http://localhost/mallapi/Sale_Master.py",{
            method:"DELETE",
            body:JSON.stringify(
                {
                    sale_id:sid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}

        }).then(response=>{
            response.json()
            navigate("/MasterShow")
           
        }).then(json=>{
            console.log(json)
        })
    }

    return(
        <div className="text-center">
            <h1>Delete Sale Detail </h1>
            Sale  Id<input type="text" className="form-control" disabled={true}  placeholder="Sale  Id" onChange={(e)=>setSid(e.target.value)}value={sid}/><br/>
            <input type="button" className="btn btn-danger" value="Delete" onClick={Delete}/>

        </div>
    )
}
export default MasterDelete;