import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function MasterUpdate(){

    const{sale,counter,emp,date,gst,total}=useParams();
    const[sid,setSid]=useState(sale);
    const[cid,setCid]=useState(counter);
    const[eid,setEid]=useState(emp);
    const[sdate,setSdate]=useState(date);
    const[gt,setGt]=useState(gst);
    const[gtot,setGtot]=useState(total);
    const navigate=useNavigate();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);

    const Update=()=>{
        fetch("http://localhost/mallapi/Sale_Master.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    
                   sale_id:sid,
                    counter_id:cid,
                    emp_id:eid,
                    sale_date:sdate,
                    gst:gt,
                    grand_total:gtot
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/MasterShow")
          
        }).then(json=>{
            console.log(json)
        })

    }

    
    const EmpShow=()=>{
        fetch("http://localhost/mallapi/Counter.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])

            const Show=()=>{
                fetch("http://localhost/mallapi/Employee.py")
              
                .then((Response) => {
                    if (!Response.ok) {
                        throw new Error("Network response was not ok");
            
                    }
                    return Response.json();
            
                })
                        .then((data) => {
            
                            setCall(data)
                            console.log(data)
                        })
                        .catch((error) => {
                            console.error("there was a problem with the fetch operation", error);
                        });
            }
            useEffect(()=>EmpShow(),[])
         


    return(
        <div className="text-center">
            <h1>Update Sale Master</h1>
            Sale id<input type="text" className="form-control" placeholder="Sale Id" onChange={(e)=>setSid(e.target.value)}value={sid}/><br/>

            Counter Id<select className="form-control" onChange={(e)=>setCid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.counter_id}>{data.counter_nm}</option>)
                })
            }     
            </select><br/>
            Employee Id<select className="form-control" onChange={(e)=>setEid(e.target.value)}>{
                call.map((data)=>{
                    return(<option value={data.emp_id}>{data.emp_nm}</option>)
                })
            }     
            </select><br/>
           
            Sale Date<input type="date" className="form-control"  onChange={(e)=>setSdate(e.target.value)}value={sdate}/><br/>
            GST<input type="text" className="form-control" placeholder="GST" onChange={(e)=>setGt(e.target.value)}value={gt}/><br/>
            Grand Total<input type="text" className="form-control" placeholder="Grand Total" onChange={(e)=>setGtot(e.target.value)}value={gtot}/><br/>
            <input type="button" className="btn btn-warning" value="Update" onClick={Update}/>
        </div>
    )
}
export default MasterUpdate;