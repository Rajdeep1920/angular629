import {  useState } from "react";

function SaleMasterDatewise(){
    
    const[fdate,setFdate]=useState();
    const[tdate,setTdate]=useState();
    const[all,setAll]=useState([]);


    const Insert=()=>{

        fetch("http://localhost/mallapi/ReportApi/SaleMasterDatewise.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    fromdate:fdate,
                    todate:tdate
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
           return response.json()
        }).then(json=>{
            setAll(json)
           
            console.log(json)
        })
    }
    
    

    return(
        <div className="text-center">
             <h1>Sale Master DateWise Report</h1>
            From Date<input type="date" className="form-control" onChange={(e)=>setFdate(e.target.value)}/><br/>
            To Date<input type="date" className="form-control" onChange={(e)=>setTdate(e.target.value)}/><br/>
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered"  border={"2px"}>
                <tr>
                    <th>Sale Id</th>
                    <th>Counter Id</th>
                    <th>Employee Id</th>
                    <th>Sale Date</th>
                    <th>GST</th>
                    <th>Grand Total</th>
                    
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.sale_id}</td>
                        <td>{data.counter_id}</td>
                        <td>{data.emp_id}</td>
                        <td>{data.sale_date}</td>
                        <td>{data.gst}</td>
                        <td>{data.grand_total}</td>
                       
                    </tr>
                    )
                }


            </table>

        </div>
    )
}
export default SaleMasterDatewise;