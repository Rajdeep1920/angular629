import {  useState } from "react";

function ReceiptDatewise(){
    
    const[fdate,setFdate]=useState();
    const[tdate,setTdate]=useState();
    const[all,setAll]=useState([]);


    const Insert=()=>{

        fetch("http://localhost/mallapi/ReportApi/RecieptWiseDatewise.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    fromdate:fdate,
                    todate:tdate
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
           return response.json()
        }).then(json=>{
           setAll(json)
            console.log(json)
        })
    }
    
    

    return(
        <div className="text-center">
             <h1>Receipt DateWise Report</h1>
            From Date<input type="date" className="form-control" onChange={(e)=>setFdate(e.target.value)}/><br/>
            To Date<input type="date" className="form-control" onChange={(e)=>setTdate(e.target.value)}/><br/>
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Receipt Id</th>
                    <th>Receipt Date</th>
                    <th>Customer Phone No</th>
                    <th>Receipt Amount</th>
                    
                </tr>
                {
                    all.map((data)=>
                        <tr>
                            <td>{data.rec_id}</td>
                            <td>{data.rec_date}</td>
                            <td>{data.cust_phno}</td>
                            <td>{data.rec_amt}</td>
                           
                        </tr>
                    )
                }

            </table>


        </div>
    )
}
export default ReceiptDatewise;