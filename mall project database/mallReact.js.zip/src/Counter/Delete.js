import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function CounterDelete(){
    const{c_id}=useParams()
    const[cid,setCid]=useState(c_id);
    const navigate=useNavigate();

    const Delete=()=>{
        fetch("http://localhost/mallapi/Counter.py",{
            method:"DELETE",
            body:JSON.stringify(
                {
                    
                    'counter_id':cid
                }
            ),
            headers:{"content-type": "application/json;charset=UTF-8"}
        }
        ).then(response=>{
            response.json()
            navigate("/CounterShow")
            
        }).then(json=>{
            console.log(json)
        })
        
    }

    return(
        <div className="text-center">
            <h1>Delete Counter Data</h1>
            Counter Id<input type="text" placeholder="Counter Id" className="form-control" disabled={true} onChange={(e)=>setCid(e.target.value)}value={cid}/><br/>
            <input type="button" value="Delete" className="btn btn-danger" onClick={Delete}/>

        </div>
    )
}
export default CounterDelete;