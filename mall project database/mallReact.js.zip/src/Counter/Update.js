import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function CounterUpdate(){
    const{c_id,c_name}=useParams()
    const[cid,setCid]=useState(c_id);
    const[cnm,setCnm]=useState(c_name);
    const navigate=useNavigate();

    const Update=()=>{
        fetch("http://localhost/mallapi/Counter.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    counter_id:cid,
                    counter_nm:cnm
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/CounterShow")
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Update Counter Data</h1>
            Counter Id<input type="text" className="form-control" placeholder="Counter Id" disabled={true} onChange={(e)=>setCid(e.target.value)}value={cid}/><br/>
            Counter Name<input type="text" className="form-control" placeholder="Counter Name" onChange={(e)=>setCnm(e.target.value)}value={cnm}/><br/>
            <input type="button" className="btn btn-warning" value="Update" onClick={Update}/>
        </div>
    )
}
export default CounterUpdate;