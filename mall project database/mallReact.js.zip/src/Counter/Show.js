import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom";
import "./logo.jpg"



function CounterShow(){

    const [all,setAll]=useState([]);
    const navigate=useNavigate();

    const Show=()=>{
        fetch("http://localhost/mallapi/Counter.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])
            const NewData=()=>{
                navigate("/CounterInsert")
            }

            const mystyle={
                color:"red",
                textAlign:"center",
                
            }
            const dark={
                backgroundColor:"yellow"
            }
            
    return(
        <div >
            <div style={mystyle}>
           
            <h1  style={dark}>Counter Data</h1>
            <input type="button" value="Insert New Data" className="btn btn-success " onClick={NewData}></input><br/><br/>

            <table className="table table-striped table-hover table-bordered text-center" border={"2px"}>
                
                <tr >
                    <th >Counter Id</th>
                    <th>Counter Name</th>
                    <th>Action</th>
                </tr>
              
               {
                all.map((data)=>
                <tr>
                    <td>{data.counter_id}</td>
                    <td>{data.counter_nm}</td>
                    <td><Link className="btn btn-warning" to={`/CounterUpdate/${data.counter_id}/${data.counter_nm}`}>Update</Link>
                        <Link className="btn btn-warning" to={`/CounterDelete/${data.counter_id}`}>Delete</Link>
                    </td>
                </tr>
                
                )

                
               }
            </table>
            </div>
        </div>
    )
}
export default CounterShow;