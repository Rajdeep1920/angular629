import { useState } from "react";
import { useNavigate } from "react-router-dom";

function CounterInsert(){
   
    const[cnm,setCnm]=useState();
    const navigate=useNavigate();

    const Insert=()=>{
        fetch("http://localhost/mallapi/Counter.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    
                    'counter_nm':cnm
                }
            ),
            headers:{"content-type": "application/json;charset=UTF-8"}
        }
        ).then(response=>{
            response.json()
            navigate("/CounterShow")
        }).then(json=>{
            console.log(json)
        })
        
    }

    return(
        <div className="text-center">
            <h1>Insert Counter Data</h1>
            Counter Name<input type="text" placeholder="Counter Name" className="form-control" onChange={(e)=>setCnm(e.target.value)}/><br/>
            <input type="button" value="Insert" className="btn btn-success" onClick={Insert}/>

        </div>
    )
}
export default CounterInsert;