import { useState } from "react"
import { useNavigate } from "react-router-dom";

function ReceiptInsert(){

    const [rd,setRd]=useState();
    const[cpn,setCpn]=useState();
    const[ramt,setRamt]=useState();
    const navigate=useNavigate();
    
    const Insert=()=>{
        fetch("http://localhost/mallapi/Receipt.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    rec_date:rd,
                    cust_phno:cpn,
                    rec_amt:ramt
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/ReceiptShow")
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Insert Receipt Data</h1>
            Receipt Date<input type="date" className="form-control" onChange={(e)=>setRd(e.target.value)}/><br/>
            Customer Phone no<input type=" text" className="form-control" placeholder="Customer Phone Number" onChange={(e)=>setCpn(e.target.value)}/><br/>
            Receipt Amount<input type="text" className="form-control" placeholder="Receipt Amount" onChange={(e)=>setRamt(e.target.value)}/><br/>
            <input type="button" className="btn btn-success" value="Insert" onClick={Insert}/><br/>


        </div>
    )
}
export default ReceiptInsert;
