import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function ReceiptShow(){

    const[all,setAll]=useState([]);
    const navigate=useNavigate();

    const Show=()=>{
        fetch("http://localhost/mallapi/Receipt.py")
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });


    }
    useEffect(()=>Show(),[])

    const AddNew=()=>{
        navigate("/ReceiptInsert")
    }

    return(
        <div className="text-center">
            <h1>All Receipt Data</h1>
            <input type="button" className="btn btn-success" value="Add New Data" onClick={AddNew}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Receipt Id</th>
                    <th>Receipt Date</th>
                    <th>Customer Phone No</th>
                    <th>Receipt Amount</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                        <tr>
                            <td>{data.rec_id}</td>
                            <td>{data.rec_date}</td>
                            <td>{data.cust_phno}</td>
                            <td>{data.rec_amt}</td>
                            <td>
                                <Link className="btn btn-warning" to={`/ReceiptUpdate/${data.rec_id}/${data.rec_date}/${data.cust_phno}/${data.rec_amt}`}>Update</Link>
                                <Link className="btn btn-warning" to={`/ReceiptDelete/${data.rec_id}`}>Delete</Link>
                            </td>
                        </tr>
                    )
                }

            </table>

        </div>
    )
}
export default ReceiptShow;