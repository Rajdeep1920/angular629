import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function ReceiptUpdate(){

    const{id,date,phn,amt}=useParams();
    const[rid,setRid]=useState(id);
    const[rd,setRd]=useState(date);
    const[cpn ,setCpn]=useState(phn);
    const[rmt,setRmt]=useState(amt);
    const navigate=useNavigate();

    const Update=()=>{
        fetch("http://localhost/mallapi/Receipt.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    rec_id:rid,
                    rec_date:rd,
                    cust_phno:cpn,
                    rec_amt:rmt
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/ReceiptShow")
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Update Receipt Data</h1>
            Receipt Id<input type="text" className="form-control" disabled={true} placeholder="Receipt Id" onChange={(e)=>setRid(e.target.value)}value={rid}/><br/>
            Receipt Date<input type="date" className="form-control" placeholder="Receipt Date" onChange={(e)=>setRd(e.target.value)}value={rd}/><br/>
            Customer Phone no<input type="text" className="form-control" placeholder="Customer Phone No" onChange={(e)=>setCpn(e.target.value)}value={cpn}/><br/>
            Receipt Amount<input type="text" className="form-control" placeholder="Receipt Amount" onChange={(e)=>setRmt(e.target.value)}value={rmt}/><br/>
            <input type="button" className="btn btn-warning" value="Update" onClick={Update}/>
            

        </div>
    )
}
export default ReceiptUpdate;