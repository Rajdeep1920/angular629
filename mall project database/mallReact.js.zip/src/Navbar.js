import "./App.css"
import "./logo.jpg"


function Navbar(){
    return(

        <>
        
       
                        
                    
                
                
            

        
            
            {/* <ul> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/CounterInsert">Counter-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/CounterUpdate">Counter-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/CounterDelete">Counter-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/CounterShow">Counter-Showall</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DepInsert">Dep-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-decoration-none text-dark" to="/DepUpdate">Dep-Upadte</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DepDelete">Dep-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DepShow">Dep-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/EmpInsert">Employee-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/EmpUpdate">Emp-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/EmpDelete">Emp-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-decoration-none text-dark" to="/EmpShow">Emp-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemInsert">ItemInsert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemUpdate">Item-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemDelete">Item-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemShow">Item-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemCatInsert">ItemCatInsert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemCatUpdate">ItemCatUpdate</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemCatDelete">ItemCatDelete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ItemCatShow">ItemCatShow</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/PostInsert">Post-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/PostUpdate">Post-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/PostDelete">Post-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/PostShow">Post-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ReceiptInsert">Receipt-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ReceiptUpdate">Receipt-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ReceiptDelete">Receipt-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ReceiptShow">Receipt-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DetInsert">SaleDet-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DetUpdate">SaleDet-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DetDelete">SaleDet-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DetShow">SaleDet-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/MasterInsert">Master-Insert</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/MasterUpdate">Master-Update</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/MasterDelete">Master-Delete</Link></li> */}
                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/MasterShow">Master-Show</Link></li> */}

                {/* <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/CEwiseSMaster">CounterEmpWiseSaleMaster</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DepWiseItemCat">DepWiseItemCategory</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/DeptItemWiseItem">DeptItem Wise Item</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/PostWiseEmployee">PostWise Employee</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/SaleMastWiseSaleDet">SaleMaster-Item Wise Sale-Detail</Link></li>

                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/EmpDateWise">Employee Datewise</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/ReceiptDatewise">Receipt DateWise</Link></li>
                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/SaleMasterDatewise">Sale-Master Datewise</Link></li>

                <li className="list-unstyled"><Link className="text-dark text-decoration-none" to="/Log">Log-In</Link></li>
              
            </ul> */}
           
           <div class="menu__bar">
                
                <div className="logo">R<span>Mall</span></div>
                <ul>
                    <li><a href="/Home">Home</a></li>

                    <li><a href="#">Master <i class="fas fa-caret-down"></i></a>
                        <div className="dropdown__menu">
                            <ul>
                                <li><a href="/CounterShow">Counter</a></li>
                                <li><a href="/DepShow">Department</a></li>
                                <li><a href="/EmpShow">Employee</a></li>
                                <li><a href="/ItemShow">Item</a></li>
                                <li><a href="/ItemCatShow">Item-Category</a></li>
                                <li><a href="/PostShow">Post</a></li>
                                
                            </ul>
                        </div>
                    </li>


                    <li><a href="#">Transaction <i class="fas fa-caret-down"></i></a>
                        <div className="dropdown__menu">
                            <ul>
                                <li><a href="/ReceiptShow">Receipt</a></li>
                                <li><a href="/DetShow">Sale-Detail</a></li>
                                <li><a href="/MasterShow">Sale-Master</a></li>
                            </ul>
                        </div>
                    </li>




                    <li><a href="#">Date Wise <i class="fas fa-caret-down"></i></a>
                        <div className="dropdown__menu">
                            <ul>
                                <li><a href="/SaleMasterDatewise">Sale-Master Date</a></li>
                                <li><a href="/ReceiptDatewise">Receipt Date</a></li>
                                <li><a href="/EmpDatewise">Employee Date</a></li>
                            </ul>
                        </div>
                    </li>



                    <li><a href="#">Dynamic Report <i class="fas fa-caret-down"></i></a>
                        <div className="dropdown__menu">
                            <ul>
                                <li><a href="/CEwiseSMaster">Sale-Master</a></li>
                                <li><a href="/DepWiseItemCat">Item-Category</a></li>
                                <li><a href="/DeptItemWiseItem">Item</a></li>
                                <li><a href="/PostWiseEmp">Employee</a></li>
                                <li><a href="/SaleMastWiseSaleDet"> Sale-Detail</a></li>
                            </ul>
                        </div>
                    </li>



                    <li><a href="/Log">Login</a></li>
                    <li><a href="/ReceiptInvoice">Recepit</a></li>

                </ul>
            </div>





       
       
        
        </>
        
    );
}
export default Navbar;