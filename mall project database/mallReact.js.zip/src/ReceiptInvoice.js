import { useEffect, useState } from 'react'
import'./Receipt.css' 
import { useParams } from 'react-router-dom';

function ReceiptInvoice(){
    const{sale_id}=useParams();
    const[sid,setSid]=useState(sale_id);
    const [list,setList]=useState([{}])


        const ShowReceipt=()=>{
            fetch("http://localhost/mallapi/ReportApi/Invoice.py",{
                method:"POST",
                body:JSON.stringify(
                    {
                        'sale_id':sid
                    }
                ),
                headers:{"content-type":"application/json;charset=UTF-8"}
            }).then(response=>{
               return response.json()
            }).then(json=>{
                setList(json)
                console.log(json)
            })
        }
        useEffect(()=>ShowReceipt(),[])
    return(
        <div class="rec">
            <div class='img'>
            <div className="text-center p-3">
                <h2>R-Mall<sup>&reg;</sup></h2>
                <hr style={{borderTop:"3px dotted white"}}></hr>
                
            </div>

            <div className="text-center">
                <h5>CIN :- L510900MH2000PLC126473</h5>
                <h5>GSTIN :- </h5>
                <h6>FSSAI NO :- 1512013000113</h6>
                <hr style={{borderTop:"3px dotted white"}}></hr>
            </div>

            <div className="text-center">
                <h3>R-Mall</h3>
                <h6>Survey No 21, Plot No 131 b 1,<br/>
                5 Star MIDC, Kagal<br/>
                Kagal, Kolhapur</h6>
                <h4>Phone: 7875774799</h4>
                <hr style={{borderTop:"3px dotted white"}}></hr>
            </div>
            <div className="text-center">
                <h4>Bill Invoice</h4>
                <div className="container">
                    <div className="row">
                        <div className="col-6">
                            <h6>Bill No : {sid}</h6>
                           
                        </div>
                        <div className="col-6">
                            <h6>Bill Date : {list[0].sale_date}</h6>
                            <h6>Counter Name : {list[0].counter_nm}</h6>
                        </div>
                        <hr style={{borderTop:"3px dotted white"}}></hr>
                    </div>

                </div>
            </div>

            <div>
                <table className="table table-striped table-hover table-bordered" border={"2px"}>
                    <tr>
                        <th>Item No</th>
                        <th>Particulars</th>
                        <th>Qty/Kg</th>
                        <th>N/Rate</th>
                        <th>Value</th>
                    </tr>
                    {list.map((data,index)=>(
                        <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{data.item_nm}</td>
                        <td>{data.item_qty}</td>
                        <td>{data.item_rate}</td>
                        <td>{data.item_amt}</td>
                    </tr>

                   ) ) }
                   
                </table>
            </div>

          <div className="container">
                <div className="row">
                    <div className="col-8">
                            {/* Empty Content */}
                    </div>

                    <div className="col-4">
                        <div className="row">
                        <div className="col-5 ">
                           
                            CGST 2.5%<br/>
                            SGST 2.5%<br/>
                            <h4>Grand Total:</h4>
                        </div>

                        <div className="col-1 ">
                         
                            {list[0].gst}<br/>
                            {list[0].gst}<br/>
                           {list[0].grand_total}
                        </div>
                        </div>
                    </div>

                </div>

            </div>
            <hr style={{borderTop:"3px dotted white"}}></hr>

            <h3 className="text-center">Thank You </h3>
            <h5 className="text-center">Visit Again</h5>
            
            </div>
        </div>
    )
}
export default ReceiptInvoice;