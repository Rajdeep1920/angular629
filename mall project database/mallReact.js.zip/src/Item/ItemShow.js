import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function ItemShow(){

    const[all,setAll]=useState([]);
    const navigate=useNavigate();

    const Show=()=>{
        fetch("http://localhost/mallapi/Item.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])
            const AddNew=()=>{
                navigate("/ItemInsert")
            }
    return(
        <div className="text-center">

            <h1>Item Data</h1>
            <input type="button" value="Add New Data" className="btn btn-success" onClick={AddNew}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Item Id</th>
                    <th>Department Id</th>
                    <th>Category Id</th>
                    <th>Item Name</th>
                    <th>Item UOM</th>
                    <th>Item Stock</th>
                    <th>Item Rate</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.item_id}</td>
                        <td>{data.dept_id}</td>
                        <td>{data.cat_id}</td>
                        <td>{data.item_nm}</td>
                        <td>{data.item_UOM}</td>
                        <td>{data.item_stock}</td>
                        <td>{data.item_rate}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/ItemUpdate/${data.item_id}/${data.dept_id}/${data.cat_id}/${data.item_nm}/${data.item_UOM}/${data.item_stock}/${data.item_rate}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/ItemDelete/${data.item_id}`}>Delete</Link>
                        </td>
                    </tr>
                    )
                }
                
            </table>

        </div>
    )
}
export default ItemShow;