import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";

function ItemInsert(){


    const[did,setDid]=useState();
    const[cid,setCid]=useState();
    const[inm,setInm]=useState();
    const[iuom,setIuom]=useState();
    const[ist,setIst]=useState();
    const navigate=useNavigate();
    const[ir,setIr]=useState();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);
    

    const Insert=()=>{
        fetch("http://localhost/mallapi/Item.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    dept_id:did,
                    cat_id:cid,
                    item_nm:inm,
                    item_UOM:iuom,
                    item_stock:ist,
                    item_rate:ir
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/ItemShow")
        }).then(json=>{
            console.log(json)
        })
    }

    const DepShow=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>DepShow(),[])

            const ItemCatShow=()=>{
                fetch("http://localhost/mallapi/Item_category.py")
                
                .then((Response) => {
                    if (!Response.ok) {
                        throw new Error("Network response was not ok");
            
                    }
                    return Response.json();
            
                })
                        .then((data) => {
            
                            setCall(data)
                            console.log(data)
                        })
                        .catch((error) => {
                            console.error("there was a problem with the fetch operation", error);
                        });
            }
            useEffect(()=>ItemCatShow(),[])

    return(
        <div className="text-center">
            <h1>Add Insert Data</h1>
           
            Department Id<select className="form-control" onChange={(e)=>setDid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.dept_id}>{data.dept_nm}</option>)
                })
            }     
            </select><br/>
            Category Id<select className="form-control" onChange={(e)=>setCid(e.target.value)}>{
                call.map((data)=>{
                    return(<option value={data.cat_id}>{data.cat_nm}</option>)
                })
            }     
            </select><br/>
            Item Name<input type="text" placeholder="Item Name" className="form-control" onChange={(e)=>setInm(e.target.value)}/><br/>
            Item Unit Of Measure<input type="text" placeholder="Item Unit of Measure" className="form-control" onChange={(e)=>setIuom(e.target.value)}/><br/>
            Item Stock<input type="text" placeholder="Item Stock" className="form-control" onChange={(e)=>setIst(e.target.value)}/><br/>
            Item Rate<input type="text" placeholder="Item Rate" className="form-control" onChange={(e)=>setIr(e.target.value)}></input><br/>
            <input type="button" value="Insert" className="btn btn-success" onClick={Insert}/>
        </div>
    )
}
export default ItemInsert;