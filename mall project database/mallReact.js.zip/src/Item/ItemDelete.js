import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function ItemDelete(){

    const{itid}=useParams();
    const[iid,setIid]=useState(itid);
    const navigate=useNavigate();

    const Delete=()=>{
        fetch("http://localhost/mallapi/Item.py",{
            method:"DELETE",
            body:JSON.stringify(
                {
                    item_id:iid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}

        }).then(response=>{
            response.json()
            navigate("/ItemShow")
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Delete Item Data</h1>
            Item Id<input type="text" placeholder="Item Id" disabled={true} className="form-control" onChange={(e)=>setIid(e.target.value)}value={iid}/><br/>
            <input type="button" className="btn btn-danger" value="Delete" onClick={Delete}/>
        </div>
    )
}
export default ItemDelete;
