import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function ItemUpdate(){

    const{itid,dpid,ctid,itnm,ituom,itst,irt}=useParams();
    const[iid,setIid]=useState(itid);
    const[did,setDid]=useState(dpid);
    const[cid,setCid]=useState(ctid);
    const[inm,setInm]=useState(itnm);
    const[iuom,setIuom]=useState(ituom);
    const[ist,setIst]=useState(itst);
    const navigate=useNavigate();
    const[ir,setIr]=useState(irt)
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);

    const Update=()=>{
        fetch("http://localhost/mallapi/Item.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    item_id:iid,
                    dept_id:did,
                    cat_id:cid,
                    item_nm:inm,
                    item_UOM:iuom,
                    item_stock:ist,
                    item_rate:ir
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/ItemShow")
        }).then(json=>{
            console.log(json)
        })
    }

    
    const DepShow=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>DepShow(),[])

            const ItemCatShow=()=>{
                fetch("http://localhost/mallapi/Item_category.py")
                
                .then((Response) => {
                    if (!Response.ok) {
                        throw new Error("Network response was not ok");
            
                    }
                    return Response.json();
            
                })
                        .then((data) => {
            
                            setCall(data)
                            console.log(data)
                        })
                        .catch((error) => {
                            console.error("there was a problem with the fetch operation", error);
                        });
            }
            useEffect(()=>ItemCatShow(),[])
    return(
        <div className="text-center">
            <h1>Update Item Data</h1>
            Item Id<input type="text" className="form-control" disabled={true} placeholder="Item Id" onChange={(e)=>setIid(e.target.value)}value={iid}/><br/>
            Department Id<select className="form-control" onChange={(e)=>setDid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.dept_id}>{data.dept_nm}</option>)
                })
            }     
            </select><br/>
            Category Id<select className="form-control" onChange={(e)=>setCid(e.target.value)}>{
                call.map((data)=>{
                    return(<option value={data.cat_id}>{data.cat_nm}</option>)
                })
            }     
            </select><br/>
            Item Name<input type="text" placeholder="Item Name" className="form-control" onChange={(e)=>setInm(e.target.value)}value={inm}/><br/>
            Item Unit Of Measure<input type="text" placeholder="Item Unit of Measure" className="form-control" onChange={(e)=>setIuom(e.target.value)}value={iuom}/><br/>
            Item Stock<input type="text" placeholder="Item Stock" className="form-control" onChange={(e)=>setIst(e.target.value)}value={ist}/><br/>
            Item Rate<input type="text" placeholder="Item Rate" className="form-control" onChange={(e)=>setIr(e.target.value)} value={ir}/><br/>
            <input type="button" value="Update" className="btn btn-warning" onClick={Update}/>
        </div>
    )
}
export default ItemUpdate;