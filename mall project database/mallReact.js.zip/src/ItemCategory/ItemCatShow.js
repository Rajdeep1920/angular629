import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function ItemCatShow(){

    const [all,setAll]=useState([]);
    const navigate=useNavigate();
    const Show=()=>{
        fetch("http://localhost/mallapi/Item_category.py")
        
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    }
    useEffect(()=>Show(),[])
    const AddNew=()=>{
        navigate("/ItemCatInsert")
    }

    return(
        <div className="text-center">
            <h1>Item Category Data</h1>
            <input type="button" value="Add New Data" className="btn btn-success" onClick={AddNew}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Category Id</th>
                    <th>Department Id</th>
                    <th>Category Name</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.cat_id}</td>
                        <td>{data.dept_id}</td>
                        <td>{data.cat_nm}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/ItemCatUpdate/${data.cat_id}/${data.dept_id}/${data.cat_nm}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/ItemCatDelete/${data.cat_id}`}>Delete</Link>
                        </td>
                    </tr>
                    )
                }
            </table>
        </div>
    )
}
export default ItemCatShow;