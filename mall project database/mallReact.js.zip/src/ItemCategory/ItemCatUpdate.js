import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function ItemCatUpdate(){
    const{ctid,dtid,ctnm}=useParams();
    const [did,setDid]=useState(dtid);
    const[cnm,setCnm]=useState(ctnm);
    const[cid,setCid]=useState(ctid);
    const[all,setAll]=useState([]);
    const navigate=useNavigate();

    const Update=()=>{
        fetch("http://localhost/mallapi/Item_category.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    cat_id:cid,
                    dept_id:did,
                    cat_nm:cnm
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/ItemCatShow")
        }).then(json=>{
            console.log(json)
        })
    }
    
    const Show=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])
    return(
        <div className="text-center">
            <h1>Insert Item Category Data</h1>
            Category Id<input type="text" placeholder="Category Id" disabled={true} className="form-control" onChange={(e)=>setCid(e.target.value)}value={cid}></input><br/>
            Department Id<select className="form-control" onChange={(e)=>setDid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.dept_id}>{data.dept_nm}</option>)
                })
            }     
            </select><br/>
            Category Name<input type="text" placeholder="Category Name" className="form-control" onChange={(e)=>setCnm(e.target.value)}value={cnm}/><br/>
            <input type="button" value="Update" className="btn btn-warning" onClick={Update}/>
        </div>
    )
}
export default ItemCatUpdate;