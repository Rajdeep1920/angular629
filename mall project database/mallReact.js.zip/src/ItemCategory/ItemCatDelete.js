import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function ItemCatDelete(){

const {ctid}=useParams();
const[cid,setCid]=useState(ctid);
const navigate=useNavigate();

    const Delete=()=>{
        fetch("http://localhost/mallapi/Item_category.py",{
            method:"DELETE",
            body:JSON.stringify(
                {
                    cat_id:cid
                }
            ),
            headers:{"content-type":"application/json;charsert=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/ItemCatShow")
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">
            <h1>Delete Item Category Data</h1>
            Item Id<input type="text" className="form-control" disabled={true} placeholder="Item id" onChange={(e)=>setCid(e.target.value)}value={cid}/><br/>
            <input type="button" value="Delete" className="btn btn-danger" onClick={Delete}/>
        </div>
    )
}
export default ItemCatDelete;