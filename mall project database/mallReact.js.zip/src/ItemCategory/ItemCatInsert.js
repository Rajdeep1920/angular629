import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";

function ItemCatInsert(){

    const [did,setDid]=useState();
    const[cnm,setCnm]=useState();
    const navigate=useNavigate();
    const[all,setAll]=useState([]);

    const Insert=()=>{
        fetch("http://localhost/mallapi/Item_category.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    dept_id:did,
                    cat_nm:cnm
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
             response.json()
            navigate("/ItemCatShow")
        }).then(json=>{
            console.log(json)
        })
    }

    const Show=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>Show(),[])
    return(
        <div className="text-center">
            <h1>Insert Item Category Data</h1>
            Department Id<select className="form-control" onChange={(e)=>setDid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.dept_id}>{data.dept_nm}</option>)
                })
            }     
            </select><br/>
            Category Name<input type="text" placeholder="Category Name" className="form-control" onChange={(e)=>setCnm(e.target.value)}/><br/>
            <input type="button" value="Insert" className="btn btn-success" onClick={Insert}/>
        </div>
    )
}
export default ItemCatInsert;