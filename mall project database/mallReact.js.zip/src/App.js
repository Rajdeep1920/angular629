

import { BrowserRouter, Route, Routes, useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import CounterInsert from './Counter/Insert';
import CounterUpdate from './Counter/Update';
import CounterDelete from './Counter/Delete';
import CounterShow from './Counter/Show';

import DepInsert from './Department/DepInsert';
import DepUpdate from './Department/DepUpdate';
import DepDelete from './Department/DepDelete';
import DepShow from './Department/DepShow';

import EmpInsert from './Employee/EmpInsert';
import EmpUpdate from './Employee/EmpUpdate';
import EmpDelete from './Employee/EmpDelete';
import EmpShow from './Employee/EmpShow';

import ItemInsert from './Item/ItemInsert';
import ItemUpdate from './Item/ItemUpdate';
import ItemDelete from './Item/ItemDelete';
import ItemShow from './Item/ItemShow';

import ItemCatInsert from './ItemCategory/ItemCatInsert';
import ItemCatUpdate from './ItemCategory/ItemCatUpdate';
import ItemCatDelete from './ItemCategory/ItemCatDelete';
import ItemCatShow from './ItemCategory/ItemCatShow';

import PostInsert from './Post/PostInsert';
import PostUpdate from './Post/PostUpdate';
import PostDelete from './Post/PostDelete';
import PostShow from './Post/PostShow';

import ReceiptInsert from './Receipt/ReceiptInsert';
import ReceiptUpdate from './Receipt/ReceiptUpdate';
import ReceiptDelete from './Receipt/ReceiptDelete';
import ReceiptShow from './Receipt/ReceiptShow';

import SaleDetInsert from './SaleDetail/SaleDetInsert';
import SaleDetUpdate from './SaleDetail/SaleDetUpdate';
import SaleDetDelete from './SaleDetail/SaleDetDelete';
import SaleDetShow from './SaleDetail/SaleDetShow';

import MasterInsert from './SaleMaster/SaleMasterInsert';
import MasterUpdate from './SaleMaster/SaleMasterUpdate';
import MasterDelete from './SaleMaster/SaleMasterDelete';
import MasterShow from './SaleMaster/SaleMasterShow';

import CounterEmployeeWiseSaleMaster from './Reports/CounterEmployeeWiseSaleMaster';
import DepartmentWiseItemCategory from './Reports/DepartmentWiseItemCategory';
import DeptItemWiseItem from './Reports/DeptItemWiseItem';
import PostWiseEmp from './Reports/PostWiseEmp';
import SaleMasterItemWiseSaleDetail from './Reports/SaleMasterItemWiseSaleDetail';

import EmployeeDatewise from './DateWiseReports/EmployeeDatewise';
import ReceiptDatewise from './DateWiseReports/ReceiptDatewise';
import SaleMasterDatewise from './DateWiseReports/SaleMasterDatewise';

import LogIn from './LogIn';
import Home from './Home';
import ReceiptInvoice from './ReceiptInvoice';


import { useEffect, useState } from 'react';





function App() {
const[username,setUsername]=useState();
const[password,setPassword]=useState();
const[flag,setFlag]=useState(false);



const checkLogin=()=>{
  if(username==="Raj" && password==="123")
  {
    setFlag(true);
    <li><a href='/Home'></a></li>
  }
}

  return (
    <div>
      
      <BrowserRouter>
      {flag? (
        <div>
      <Navbar/>
   

    

      <Routes>
        <Route path='/Home' element={<Home/>}></Route>


        <Route path="/CounterInsert" element={<CounterInsert/>}></Route>
        <Route path="/CounterUpdate/:c_id/:c_name" element={<CounterUpdate/>}></Route>
        <Route path="/CounterDelete/:c_id" element={<CounterDelete/>}></Route>
        <Route path="/CounterShow" element={<CounterShow/>}></Route>

        <Route path="/DepInsert" element={<DepInsert/>}></Route>
        <Route path="/DepUpdate/:d_id/:d_nm" element={<DepUpdate/>}></Route>
        <Route path='/DepDelete/:d_id' element={<DepDelete/>}></Route>
        <Route path='/DepShow' element={<DepShow/>}></Route>

        <Route path="/EmpInsert" element={<EmpInsert/>}></Route>
        <Route path='/EmpUpdate/:epid/:ptid/:sfname/:epnm/:epadd/:eppn/:epml/:epsal/:epdob/:epdoj' element={<EmpUpdate/>}></Route>
        <Route path='/EmpDelete/:epid' element={<EmpDelete/>}></Route>
        <Route path='/EmpShow' element={<EmpShow/>}></Route>

        <Route path='/ItemInsert' element={<ItemInsert/>}></Route>
        <Route path="/ItemUpdate/:itid/:dpid/:ctid/:itnm/:ituom/:itst/:irt" element={<ItemUpdate/>}></Route>
        <Route path="/ItemDelete/:itid" element={<ItemDelete/>}></Route>
        <Route path='/ItemShow' element={<ItemShow/>}></Route>

        <Route path="/ItemCatInsert" element={<ItemCatInsert/>}></Route>
        <Route path='/ItemCatUpdate/:ctid/:dtid/:ctnm' element={<ItemCatUpdate/>}></Route>
        <Route path="/ItemCatDelete/:ctid" element={<ItemCatDelete/>}></Route>
        <Route path='/ItemCatShow' element={<ItemCatShow/>}></Route>

        <Route path='/PostInsert' element={<PostInsert/>}></Route>
        <Route path='/PostUpdate/:ptid/:ptnm' element={<PostUpdate/>}></Route>
        <Route path='/PostDelete/:ptid' element={<PostDelete/>}></Route>
        <Route path='/PostShow' element={<PostShow/>}></Route>

        <Route path="/ReceiptInsert" element={<ReceiptInsert/>}></Route>
        <Route path='/ReceiptUpdate/:id/:date/:phn/:amt' element={<ReceiptUpdate/>}></Route>
        <Route path='/ReceiptDelete/:id' element={<ReceiptDelete/>}></Route>
        <Route path='/ReceiptShow' element={<ReceiptShow/>}></Route>

        <Route path='/DetInsert' element={<SaleDetInsert/>}></Route>
        <Route path="/DetUpdate/:id/:ssid/:itid/:rate/:qty/:amt" element={<SaleDetUpdate/>}></Route>
        <Route path="/DetDelete/:id" element={<SaleDetDelete/>}></Route>
        <Route path='/DetShow' element={<SaleDetShow/>}></Route>

        <Route path='/MasterInsert' element={<MasterInsert/>}></Route>
        <Route path='/MasterUpdate/:sale/:counter/:emp/:date/:gst/:total' element={<MasterUpdate/>}></Route>
        <Route path='/MasterDelete/:sale' element={<MasterDelete/>}></Route>
        <Route path='/MasterShow' element={<MasterShow/>}></Route>

        <Route path='/CEwiseSMaster' element={<CounterEmployeeWiseSaleMaster/>}></Route>
        <Route path="/DepWiseItemCat" element={<DepartmentWiseItemCategory/>}></Route>
        <Route path="/DeptItemWiseItem" element={<DeptItemWiseItem/>}></Route>
        <Route path="/PostWiseEmp" element={<PostWiseEmp/>}></Route>
        <Route path='/SaleMastWiseSaleDet' element={<SaleMasterItemWiseSaleDetail/>}></Route>

        <Route path="/EmpDateWise" element={<EmployeeDatewise/>}></Route>
        <Route path="/ReceiptDatewise" element={<ReceiptDatewise/>}></Route>
        <Route path='/SaleMasterDatewise' element={<SaleMasterDatewise/>}></Route>

      
        
        <Route path='/ReceiptInvoice/:sale_id' element={<ReceiptInvoice/>}></Route>
        {/* <Route path='/login' element={<LogIn/>}></Route> */}
      </Routes>

        </div>):(
          <div class="textt" >
          <div class="log">
          <h1 class="new">WelCome To R-Mall</h1>
          <div class="new1">
          <h6>Enter the User-Name</h6>
          <input type="text" placeholder="Username" value={username} onChange={(e)=>setUsername(e.target.value)}/><br/><br/>
          <h6>Enter the Password</h6>
          <input type="password" placeholder="Password" value={password} onChange={(e)=>setPassword(e.target.value)}/><br></br><br/>
          <input type="button" className="btn btn-success" onClick={checkLogin} value="Submit" /><br/>
          </div>

          </div>
         
      </div>
        )}
      </BrowserRouter>

    </div>
  );
}
export default App;