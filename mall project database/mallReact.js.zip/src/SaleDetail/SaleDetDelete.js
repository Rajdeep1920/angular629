import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function SaleDetDelete(){

    const{id}=useParams();
    const[sdid,setSdid]=useState(id);
    const navigate=useNavigate();

    const Delete=()=>{

        fetch("http://localhost/mallapi/sale_detail.py",{
            method:"DELETE",
            body:JSON.stringify(
                {
                    sale_det_id:sdid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}

        }).then(response=>{
            response.json()
            navigate("/DetShow")
        }).then(json=>{
            console.log(json)
        })
    }

    return(
        <div className="text-center">
            <h1>Delete Sale Detail </h1>
            Sale Detail Id<input type="text" className="form-control" disabled={true} placeholder="Sale Detail Id" onChange={(e)=>setSdid(e.target.value)}value={sdid}/><br/>
            <input type="button" className="btn btn-danger" value="Delete" onClick={Delete}/>

        </div>
    )
}
export default SaleDetDelete;