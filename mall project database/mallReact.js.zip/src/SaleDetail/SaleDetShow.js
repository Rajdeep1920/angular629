import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";


function SaleDetShow(){


    const[all,setAll]=useState([]);
    const navigate=useNavigate();

    const Show=()=>{
        fetch("http://localhost/mallapi/sale_detail.py")

        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });


   
    }
    useEffect(()=>Show(),[])

    const AddNew=()=>{
        navigate("/DetInsert")
    }

    return(
        <div className="text-center">
            <h1>Sale Detail Data</h1>
            <input type=" text" className="btn btn-success" value="Add New Data" onClick={AddNew}/><br/><br/>

            <table className="table  table-striped table-hover table-bordered"  border={"2px"}>
                <tr>
                    <th>Sale Detail Id</th>
                    <th>Sale Id</th>
                    <th>Item Id</th>
                    <th>Item Rate</th>
                    <th>Item Quntity</th>
                    <th>Item Amount</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.sale_det_id}</td>
                        <td>{data.sale_id}</td>
                        <td>{data.item_id}</td>
                        <td>{data.item_rate}</td>
                        <td>{data.item_qty}</td>
                        <td>{data.item_amt}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/DetUpdate/${data.sale_det_id}/${data.sale_id}/${data.item_id}/${data.item_rate}/${data.item_qty}/${data.item_amt}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/DetDelete/${data.sale_det_id}`}>Delete</Link>
                            <Link className="btn btn-warning" to={`/ReceiptInvoice/${data.sale_id}`}>Receipt</Link>
       
                        </td>
                    </tr>
                    )
                }


            </table>

        </div>
    )
}
export default SaleDetShow;