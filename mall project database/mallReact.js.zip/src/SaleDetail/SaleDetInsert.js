import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function SaleDetInsert(){

    const[sid,setSid]=useState();
    const[iid,setIid]=useState();
    const[irt,setIrt]=useState();
    const[iqty,setIqty]=useState();
    const[iamt,setIamt]=useState();
    const navigate=useNavigate();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);
    const[qty,Qty]=useState("");
    

    const Insert=()=>{
        fetch("http://localhost/mallapi/sale_detail.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    
                    sale_id:sid,
                    item_id:iid,
                    item_rate:irt,
                    item_qty:iqty,
                    item_amt:iamt
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/DetShow")
        }).then(json=>{
            console.log(json)
        })

    }

    const FetchRate=(id1)=>{
       setIid(id1)
        fetch("http://localhost/mallapi/ReportApi/SaleDetailfetchItemrate.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    item_id:id1
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then((Response) => {
            if (!Response.ok) {
              throw new Error("Network response was not ok");
            }
            return Response.json();
          })
          .then((data) => {
            setIrt(data[0].item_rate)
            console.log("item_rate" + data[0]);

            Qty(data[0].item_stock)
            console.log("item_stock"+ data[0]);
          })
          .catch((error) => {
            console.error("There was a problem with the fetch operation:", error);
          });
    } 


    const SaleMasterShow=()=>{
        fetch("http://localhost/mallapi/Sale_Master.py")

        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });


   
    }
    useEffect(()=>SaleMasterShow(),[])

    const ItemShow=()=>{
        fetch("http://localhost/mallapi/Item.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setCall(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>ItemShow(),[])
      

            const calculate=(iqty)=>
            {

                setIqty(iqty)
                setIamt(parseInt(irt)*parseInt(iqty))
            }

        // const ItemUpdate=()=>{
        //     fetch("http://localhost/mallapi/Item.py",{
        //     method:"PUT",
        //     body:JSON.stringify(
        //         {
        //             item_id:iid,
        //             dept_id:did,
        //             cat_id:cid,
        //             item_nm:inm,
        //             item_UOM:iuom,
        //             item_stock:ist,
        //             item_rate:ir
        //         }
        //     ),
        //     headers:{"content-type":"application/json;charset=UTF-8"}
        // }).then(response=>{
        //     response.json()
            
        // }).then(json=>{
        //     console.log(json)
        // })
        // }

    return(
        <div className="text-center">
            <h1>Insert Sale Detail</h1>
          
            Sale Id<select className="form-control" onChange={(e)=>setSid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.sale_id}>{data.sale_id}</option>)
                })
            }     
            </select><br/>
            Item Id<select className="form-control" onChange={(e)=>FetchRate(e.target.value)}>{
                call.map((data)=>{
                    return(<option value={data.item_id}>{data.item_nm}</option>)
                })
            }     
            </select><br/>
            Item Rate<input type="text" className="form-control" placeholder="Item Rate" value={irt} /><br/>
           <p style={{color:"red"}}> Remaining Stock = {qty}</p>
            
            Item Quntity{
                qty > 0 ?<input type="text" className="form-control" placeholder="Item Quntity" onChange={(e)=>calculate(e.target.value)}/>
            :<input type="text-center" className="form-control" disabled/>
            }
            Item Amount<input type="text" className="form-control" placeholder="Item Amount" value={iamt} /><br/>
            <input type="button" className="btn btn-success" value="Insert" onClick={Insert}/>
        </div>
    )
}
export default SaleDetInsert;