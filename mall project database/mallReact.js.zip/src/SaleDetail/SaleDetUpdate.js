import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function SaleDetUpdate(){

    const{id,ssid,itid,rate,qty,amt}=useParams();
    const[sdid,setSdid]=useState(id);
    const[sid,setSid]=useState(ssid);
    const[iid,setIid]=useState(itid);
    const[irt,setIrt]=useState(rate);
    const[iqt,setIqt]=useState(qty);
    const[iamt,setIamt]=useState(amt);
    const navigate=useNavigate();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);

    const Update=()=>{
        fetch("http://localhost/mallapi/sale_detail.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    sale_det_id:sdid,
                    sale_id:sid,
                    item_id:iid,
                    item_rate:irt,
                    item_qty:iqt,
                    item_amt:iamt
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/DetShow")
        }).then(json=>{
            console.log(json)
        })
    }

    const SaleMasterShow=()=>{
        fetch("http://localhost/mallapi/Sale_Master.py")

        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });


   
    }
    useEffect(()=>SaleMasterShow(),[])

    const ItemShow=()=>{
        fetch("http://localhost/mallapi/Item.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setCall(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>ItemShow(),[])


    return(
        <div className="text-center">
            <h1>Update Receipt Data</h1>
            Sale Detail Id<input type="text" className="form-control" disabled={true} placeholder="Sale Detail Id" onChange={(e)=>setSdid(e.target.value)}value={sdid}/><br/>
            Sale Id<select className="form-control" onChange={(e)=>setSid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.sale_id}>{data.sale_id}</option>)
                })
            }     
            </select><br/>
            Item Id<select className="form-control" onChange={(e)=>setIid(e.target.value)}>{
                call.map((data)=>{
                    return(<option value={data.item_id}>{data.item_nm}</option>)
                })
            }     
            </select><br/>
            Item Rate<input type="text" className="form-control" placeholder="Item Rate" onChange={(e)=>setIrt(e.target.value)}value={irt}/><br/>
            Item Quntity<input type="text" className="form-control" placeholder="Item Quntity" onChange={(e)=>setIqt(e.target.value)}value={iqt}/><br/>
            Item Amount<input type="text" className="form-control" placeholder="Item Amount" onChange={(e)=>setIamt(e.target.value)}value={iamt}/><br/>
            <input type="button" className="btn btn-warning" value="Update" onClick={Update}/>

            
        </div>
    )
}
export default SaleDetUpdate;