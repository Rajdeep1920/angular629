import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";

function EmpInsert(){

    const[pid,setPid]=useState();
    const[sfnm,setSfnm]=useState();
    const[enm,setSnm]=useState();
    const[eadd,setEadd]=useState();
    const[epn,setEpn]=useState();
    const[email,setEmail]=useState();
    const[esal,setEsal]=useState();
    const[edob,setEdob]=useState();
    const[edoj,setEdoj]=useState();
    const navigate=useNavigate();
    const[all,setAll]=useState([]);


    const Insert=()=>{
        fetch("http://localhost/mallapi/Employee.py",{
            method:'POST',
            body:JSON.stringify(
                {
                    post_id:pid,
                    shift_nm:sfnm,
                    emp_nm:enm,
                    emp_addr:eadd,
                    emp_phno:epn,
                    emp_mail:email,
                    emp_salary:esal,
                    emp_DOB:edob,
                    emp_DOJ:edoj
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/EmpShow")
        }).then(json=>{
            console.log(json)
        })
    }

    const Show=()=>{
        fetch("http://localhost/mallapi/Post.py")

        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });

    }
    useEffect(()=>Show(),[])
    return(
        <div className="text-center">
            <h1>Employee Insert Data</h1>
            Post Id<select className="form-control" onChange={(e)=>setPid(e.target.value)}>{
                all.map((data)=>{
                    return(<option value={data.post_id}>{data.post_nm}</option>)
                })
            }     
            </select><br/>
            Shift Name<input type="text" placeholder="shift Name" className="form-control" onChange={(e)=>setSfnm(e.target.value)}/><br/>
            Employee Name<input type="text" placeholder="Employee Name" className="form-control" onChange={(e)=>setSnm(e.target.value)}/><br/>
            Employee Address<input type="text" placeholder="Employee Address" className="form-control" onChange={(e)=>setEadd(e.target.value)}/><br/>
            Employee Phone No<input type="text" placeholder="Employee Phone No" className="form-control" onChange={(e)=>setEpn(e.target.value)}/><br/>
            Employee Email<input type="text" placeholder="Employee Email" className="form-control" onChange={(e)=>setEmail(e.target.value)}/><br/>
            Employee Salary<input type="text" placeholder="Employee Salary" className="form-control" onChange={(e)=>setEsal(e.target.value)}/><br/>
            Employee Date Of Birth<input type="date" className="form-control" onChange={(e)=>setEdob(e.target.value)}/><br/>
            Employee Date of Joining<input type="date" className="form-control" onChange={(e)=>setEdoj(e.target.value)}/><br/>
            <input type="button" value="Insert" className="btn btn-success" onClick={Insert} />
        </div>
    )
}
export default EmpInsert;