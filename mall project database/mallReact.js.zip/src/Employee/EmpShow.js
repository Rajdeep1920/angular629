import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function EmpShow(){

    const[all,setAll]=useState([]);
    const navigate=useNavigate();

    const Show=()=>{
        fetch("http://localhost/mallapi/Employee.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    }
    useEffect(()=>Show(),[])
    const AddNew=()=>{
        navigate("/EmpInsert")
    }

    return(
        <div className="text-center">
            <h1>Employee All Data</h1>
            <input type="button" value="Add New Data" className="btn btn-success" onClick={AddNew}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Employee ID</th>
                    <th>Post ID</th>
                    <th>Shift Name</th>
                    <th>Employee Name</th>
                    <th>Employee Address</th>
                    <th>Employee Phone No</th>
                    <th>Employee Email</th>
                    <th>Employee Salary</th>
                    <th>Employee DOB</th>
                    <th>Employee DOJ</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.emp_id}</td>
                        <td>{data.post_id}</td>
                        <td>{data.shift_nm}</td>
                        <td>{data.emp_nm}</td>
                        <td>{data.emp_addr}</td>
                        <td>{data.emp_phno}</td>
                        <td>{data.emp_mail}</td>{}
                        <td>{data.emp_salary}</td>
                        <td>{data.emp_DOB}</td>
                        <td>{data.emp_DOJ}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/EmpUpdate/${data.emp_id}/${data.post_id}/${data.shift_nm}/${data.emp_nm}/${data.emp_addr}/${data.emp_phno}/${data.emp_mail}/${data.emp_salary}/${data.emp_DOB}/${data.emp_DOJ}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/EmpDelete/${data.emp_id}`}>Delete</Link>
                        </td>
                    </tr>
                    )
                }
            </table>

        </div>
    )
}
export default EmpShow;