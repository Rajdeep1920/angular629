import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function EmpDelete(){
    const{epid}=useParams();
    const[eid,setEid]=useState(epid);
    const navigate=useNavigate();

    const Delete=()=>{
        fetch("http://localhost/mallapi/Employee.py",{
            method:'DELETE',
            body:JSON.stringify(
                {
                    emp_id:eid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/EmpShow")
        }).then(json=>{
            console.log(json)
        })
    }
    return(
        <div className="text-center">

        Employee Id:<input type="text" className="form-control" disabled={true} placeholder="Employee ID" onChange={(e)=>setEid(e.target.value)}value={eid}/><br/>
        <input type="button" className="btn btn-danger" value="Delete" onClick={Delete}/>
        </div>
    )
}
export default EmpDelete;