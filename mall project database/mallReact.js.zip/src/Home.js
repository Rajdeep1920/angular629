import './homepage.jpg';
import './home.css'
import './cloth_symbol.jpg'
import { Link } from 'react-router-dom';



function Home(){

    const pink={
        backgroundColor:"pink"
    }

    const skyblue={
        backgroundColor:"skyblue"
    }

    return(
        <div>
            <div className='text'>
         
                <h1 className='text-center p-3 '>Your Need Complete Here</h1>
           </div>

          <div style={pink} className='text-center p-4 '>
                 <h4 >To create a seamless customer experience, R-Mall of India has been <br/>thoughtfully divided into 5 unique zones spread over 4 floors that offer<br/> shopping, food and entertainment.</h4>
          </div>

          <div className='grid'>
            <div className='row'>
                <div style={skyblue} className='col-6 text-center   '><br/><br/><br/><br/><br/><br/>
                    <small>Ground Floor and First Floor</small>
                    <h1>The Ultimate Fashion Destination</h1><br/>
                   <h6> Housing over 100 fashion brands in the heart of the city, <br/>grab the best of the best from the largest selection of lifestyle products <br/>including apparels, footwear and fashion accessories.</h6>
                   <div className='clo-img'>

                   </div>
                </div>
                <div className='col-6'>
                    <div className='fashion'>
                       
                    </div>
                </div>

            </div>

            <div className='row'>

                <div className='col-6'>
                    <div className='Grocery'>
                       
                    </div>
                </div>

                <div style={pink} className='col-6 text-center  '><br/><br/><br/><br/><br/><br/>
                    <small> First Floor and Second Floor</small>
                    <h1>The Ultimate Grocery Store</h1><br/>
                    <h6>Experience a market place like no other!<br/> Redefining the customer experience in the age of convenience,<br/> get all your daily needs sorted - all under one roof.</h6>
                    <div className='gro-img'></div>
                </div>
               

            </div>


            <div className='row'>

                    

                    <div style={skyblue} className='col-6 text-center  '><br/><br/><br/><br/><br/><br/>
                        <small> Third Floor and Fourth Floor</small>
                        <h1>The Game On</h1><br/>
                        <h6>Enter the paradise of entertainment where we have got a little something <br/>for everyone from the largest toy shops to fun <br/>games, exhilarating rides, latest blockbusters and an<br/> immersive virtual world for all age groups.</h6>
                        <div className='spo-img'></div>
                    </div>

                    <div className='col-6'>
                        <div className='Sport'>
                        
                        </div>
                    </div>


            </div>

          </div>
        </div>
    )
}
export default Home;