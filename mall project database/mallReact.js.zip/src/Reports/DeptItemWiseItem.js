import { useEffect, useState } from "react"

function DeptItemWiseItem(){

    const[did,setDid]=useState();
    const[cid,setCid]=useState();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([])
    const[hall,setHall]=useState([]);

    const Insert=()=>{
        fetch("http://localhost/mallapi/ReportApi/DeptItemWiseItem.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    dept_id:did,
                    cat_id:cid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            return response.json()
        }).then(json=>{
            setHall(json)
            console.log(json)
        })

    }
    const DeptShow=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
            }
            useEffect(()=>DeptShow(),[])

            const ItemShow=()=>{
                fetch("http://localhost/mallapi/Item_category.py")
                
                .then((Response) => {
                    if (!Response.ok) {
                        throw new Error("Network response was not ok");
            
                    }
                    return Response.json();
            
                })
                        .then((data) => {
            
                            setCall(data)
                            console.log(data)
                        })
                        .catch((error) => {
                            console.error("there was a problem with the fetch operation", error);
                        });
            }
            useEffect(()=>ItemShow(),[])
    return(
        <div className="text-center">
            <h1>Department Item Wise Item</h1>
            Department Id<select className="form-control" onChange={(e)=>setDid(e.target.value)}>
                {
                    all.map((data)=>{
                        return(<option value={data.dept_id}>{data.dept_nm}</option>)
                    })
                }
            </select>
            Category Id<select className="form-control" onChange={(e)=>setCid(e.target.value)}>
                {
                    call.map((data)=>{
                        return(<option value={data.cat_id}>{data.cat_nm}</option>)
                    })
                }
            </select>
            <br/>
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
            <tr>
                    <th>Item Id</th>
                    <th>Department Id</th>
                    <th>Category Id</th>
                    <th>Item Name</th>
                    <th>Item UOM</th>
                    <th>Item Stock</th>
                  
                </tr>
                {
                    hall.map((data)=>
                    <tr>
                        <td>{data.item_id}</td>
                        <td>{data.dept_id}</td>
                        <td>{data.cat_id}</td>
                        <td>{data.item_nm}</td>
                        <td>{data.item_UOM}</td>
                        <td>{data.item_stock}</td>
                        
                    </tr>
                    )
                }

            </table>


        </div>
    )
}
export default DeptItemWiseItem;