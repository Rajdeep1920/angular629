import { useEffect, useState } from "react"

function DepartmentWiseItemCategory(){

    const[all,setAll]=useState([]);
    const[did,setDid]=useState("");
    const[call,setCall]=useState([]);

    const Insert=()=>{
        fetch("http://localhost/mallapi/ReportApi/DepartmentWiseItemCategory.py",{
            method:'POST',
            body:JSON.stringify(
                {
                    dept_id:did
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
           return response.json()
        }).then(json=>{
            setCall(json)
            console.log(json)
        })
    }

    const DepartmentShow=()=>{
        fetch("http://localhost/mallapi/Department.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
    }
    useEffect(()=>DepartmentShow(),[])
    return(
        <div className="text-center">
            <h1>Department Wise Item-Category</h1>
            <select className="form-control" onChange={(e)=>setDid(e.target.value)}>
                {
                    all.map((data)=>{
                        return(<option value={data.dept_id}>{data.dept_nm}</option>)
                    })
                }
            </select><br></br>
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered"  border={"2px"}>
            <tr>
                    <th>Category Id</th>
                    <th>Department Id</th>
                    <th>Category Name</th>
                   
                </tr>
                {
                    call.map((data)=>
                    <tr>
                        <td>{data.cat_id}</td>
                        <td>{data.dept_id}</td>
                        <td>{data.cat_nm}</td>
                        
                    </tr>
                    )
                }

            </table>

        </div>
    )
}
export default DepartmentWiseItemCategory;