import { useEffect, useState } from "react"

function CounterEmployeeWiseSaleMaster(){

    const[cid,setCid]=useState();
    const[eid,setEid]=useState();
    const[all,setAll]=useState([]);
    const[call,setCall]=useState([]);
    const[hall,setHall]=useState([]);

    const Insert=()=>{
        fetch("http://localhost/mallapi/ReportApi/CounterEmployeeWiseSaleMaster.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    counter_id:cid,
                    emp_id:eid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            return response.json()
        }).then(json=>{
            setHall(json)
            console.log(json)
        })
    }

    const CounterShow=()=>{
        fetch("http://localhost/mallapi/Counter.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    }
    useEffect(()=>CounterShow(),[])


    const EmployeeShow=()=>{
        fetch("http://localhost/mallapi/Employee.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setCall(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    }

    useEffect(()=>EmployeeShow(),[])
    return(
        <div className="text-center">
            <h1>CounterEmployee Wise Sale-Master</h1>
            Counter Id<select className="form-control" onChange={(e)=>setCid(e.target.value)}>
                {
                    all.map((data)=>{
                        return(<option value={data.counter_id}>{data.counter_nm}</option>)
                    })
                }
            </select>
            Employee Id<select className="form-control" onChange={(e)=>setEid(e.target.value)}>
                {
                    call.map((data)=>{
                        return(<option value={data.emp_id}>{data.emp_nm}</option>)
                    })
                }
            </select><br/>
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Sale Id</th>
                    <th>Counter Id</th>
                    <th>Employee Id</th>
                    <th>Sale Date</th>
                    <th>GST</th>
                    <th>Grand Total</th>
                    
                </tr>
                {
                    hall.map((data)=>
                    <tr>
                        <td>{data.sale_id}</td>
                        <td>{data.counter_id}</td>
                        <td>{data.emp_id}</td>
                        <td>{data.sale_date}</td>
                        <td>{data.gst}</td>
                        <td>{data.grand_total}</td>
                </tr>
                    )}

                
            </table>

        </div>
    )
}
export default CounterEmployeeWiseSaleMaster;