import { useEffect, useState } from "react"

function SaleMasterItemWiseSaleDetail(){

    
    const[iid,setIid]=useState();
    
    const[call,setCall]=useState([]);
    const[hall,setHall]=useState([]);

    const Insert=()=>{
    fetch("http://localhost/mallapi/ReportApi/SaleMasterItemWiseSaleDetail.py",{
        method:"POST",
        body:JSON.stringify(
            {
               
                item_id:iid

            }
        ),
        headers:{"content-type":"application/json;charset=UTF-8"}
    }).then(response=>{
        return response.json()
    }).then(json=>{
        setHall(json)
        console.log(json)
    })
}


const ItemShow=()=>{
    fetch("http://localhost/mallapi/Item.py")
  
    .then((Response) => {
        if (!Response.ok) {
            throw new Error("Network response was not ok");

        }
        return Response.json();

    })
            .then((data) => {

                setCall(data)
                console.log(data)
            })
            .catch((error) => {
                console.error("there was a problem with the fetch operation", error);
            });

        }
        useEffect(()=>ItemShow(),[])

    return (
        <div className="text-center">
            <h1>Sale Detail Report</h1>
           
            Item Id<select className="form-control" onChange={(e)=>setIid(e.target.value)}>
                {
                    call.map((data)=>{
                        return(<option value={data.item_id}>{data.item_nm}</option>)
                    })
                }
           
            </select><br/>
            
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
            <tr>
                    <th>Sale Detail Id</th>
                    <th>Sale Id</th>
                    <th>Item Id</th>
                    <th>Item Rate</th>
                    <th>Item Quntity</th>
                    <th>Item Amount</th>
                  
                </tr>
                {
                    hall.map((data)=>
                    <tr>
                        <td>{data.sale_det_id}</td>
                        <td>{data.sale_id}</td>
                        <td>{data.item_id}</td>
                        <td>{data.item_rate}</td>
                        <td>{data.item_qty}</td>
                        <td>{data.item_amt}</td>
                       
                    </tr>
                    )
                }
                
            </table>
        </div>
    )
}
export default SaleMasterItemWiseSaleDetail;