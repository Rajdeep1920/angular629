import { useEffect, useState } from "react"

function PostWiseEmp(){

    const[all,setAll]=useState([]);
    const[pid,setPid]=useState(1);
    const[call,setCall]=useState([]);

    const Insert=()=>{
        fetch("http://localhost/mallapi/ReportApi/PostWiseEmployee.py",{
            method:'POST',
            body:JSON.stringify(
                {
                    

                    post_id:pid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
           return response.json()
        }).then(json=>{
          setCall(json)
            console.log(json)
        })
    }

    const PostShow=()=>{
        fetch("http://localhost/mallapi/Post.py")
      
        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });
    
    }
    useEffect(()=>PostShow(),[])
    return(
        <div className="text-center">
            <h1>Post Wise Employee Report</h1>
            <select className="form-control" onChange={(e)=>setPid(e.target.value)}>
                {
                    all.map((data)=>{
                        return(<option value={data.post_id}>{data.post_nm}</option>)
                    })
                }
            </select><br></br>
            <input type="button" className="btn btn-success" value="Submit" onClick={Insert}/><br/><br/>
            <table className="table table-striped table-hover table-bordered"  border={"2px"}>
            <tr>
                    <th>Employee Id</th>
                    <th>Post Id</th>
                    <th>Shift Name</th>
                    <th>Employee Name</th>
                    <th>Employee Address</th>
                    <th>Employee Phone No</th>
                    <th>Employee Email</th>
                    <th>Employee Salary</th>
                    <th>Employee DOB</th>
                    <th>Employee DOJ</th>
                </tr>
                {
                    call.map((data)=>
                    <tr>
                        <td>{data.emp_id}</td>
                        <td>{data.post_id}</td>
                        <td>{data.shift_nm}</td>
                        <td>{data.emp_nm}</td>
                        <td>{data.emp_addr}</td>
                        <td>{data.emp_phno}</td>
                        <td>{data.emp_mail}</td>
                        <td>{data.emp_salary}</td>
                        <td>{data.emp_DOB}</td>
                        <td>{data.emp_DOJ}</td>
                    </tr>
                    )
                }
            </table>

        </div>
    )
}
export default PostWiseEmp;