import { useState } from "react"
import { useNavigate } from "react-router-dom";

function PostInsert(){

    const[pnm,setPnm]=useState();
    const navigate=useNavigate();

    const Insert=()=>{
        fetch("http://localhost/mallapi/Post.py",{
            method:"POST",
            body:JSON.stringify(
                {
                    post_nm:pnm
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/PostShow")
        }).then(json=>{
            console.log(json)
        })
    }

    return(
        <div className="text-center">
            <h1>Insert Post Data</h1>
            Post Name<input type="text" className="form-control" placeholder="Post Name" onChange={(e)=>setPnm(e.target.value)}/><br/>
            <input type="button" value="Insert" className="btn btn-success" onClick={Insert}/>

        </div>
    )
}
export default PostInsert;