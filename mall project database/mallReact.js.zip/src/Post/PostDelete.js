import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom";

function PostDelete(){

    const{ptid}=useParams();
    const[pid,setPid]=useState(ptid);
    const navigate=useNavigate();

    const Delete=()=>{
        fetch("http://localhost/mallapi/Post.py",{
            method:"DELETE",
            body:JSON.stringify(
                {
                    post_id:pid
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/PostShow")
        }).then(json=>{
            console.log(json)
        })
    }

    return(

        <div className="text-center">
            <h1>Delete Post Data</h1>
            Post Id<input type="text" className="form-control" disabled={true} placeholder="Post Id" onChange={(e)=>setPid(e.target.value)}value={pid}/><br/>
            <input type="button" value="Delete" className="btn btn-danger" onClick={Delete}/>

        </div>
    )
}
export default PostDelete;