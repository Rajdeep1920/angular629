import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function PostShow(){

    const [all,setAll]=useState([]);
    const navigate=useNavigate();

    const Show=()=>{
        fetch("http://localhost/mallapi/Post.py")

        .then((Response) => {
            if (!Response.ok) {
                throw new Error("Network response was not ok");
    
            }
            return Response.json();
    
        })
                .then((data) => {
    
                    setAll(data)
                    console.log(data)
                })
                .catch((error) => {
                    console.error("there was a problem with the fetch operation", error);
                });

    }
    useEffect(()=>Show(),[])
    const AddNew=()=>{
        navigate("/PostInsert")
    }

    return(
        <div className="text-center">
            <h1>Post Data</h1>
            <input type="button" value="Add New Data" className="btn btn-success" onClick={AddNew}/><br/><br/>
            <table className="table table-striped table-hover table-bordered" border={"2px"}>
                <tr>
                    <th>Post Id</th>
                    <th>Post Name</th>
                    <th>Action</th>
                </tr>
                {
                    all.map((data)=>
                    <tr>
                        <td>{data.post_id}</td>
                        <td>{data.post_nm}</td>
                        <td>
                            <Link className="btn btn-warning" to={`/PostUpdate/${data.post_id}/${data.post_nm}`}>Update</Link>
                            <Link className="btn btn-warning" to={`/PostDelete/${data.post_id}`}>Delete</Link>
                        </td>
                    </tr>
                    )
                }

            </table>

        </div>
    )
}
export default PostShow;