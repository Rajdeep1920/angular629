import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function PostUpdate(){

    const{ptid,ptnm}=useParams();
    const[pid,setPid]=useState(ptid);
    const[pnm,setPnm]=useState(ptnm);
    const navigate=useNavigate();
    const Update=()=>{
        fetch("http://localhost/mallapi/Post.py",{
            method:"PUT",
            body:JSON.stringify(
                {
                    post_id:pid,
                    post_nm:pnm
                }
            ),
            headers:{"content-type":"application/json;charset=UTF-8"}
        }).then(response=>{
            response.json()
            navigate("/PostShow")
        }).then(json=>{
            console.log(json)
        })
    }

    return(
        <div className="text-center">
            <h1>Update Post Data</h1>
            Post Id <input type="text" className="form-control" disabled={true} placeholder="Post Id" onChange={(e)=>setPid(e.target.value)}value={pid}/><br/>
            Post Name<input type="text" className="form-control" placeholder="Post Name" onChange={(e)=>setPnm(e.target.value)}value={pnm}/><br/>
            <input type="button" className="btn btn-warning" value="Update" onClick={Update}/>
        </div>
    )
}
export default PostUpdate;