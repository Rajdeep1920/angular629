

import './Log.css'




function LogIn(){

  

    return(
        <div class="textt" >
          <div class="log">
          <h1 class="new">WelCome To R-Mall</h1>
          <div class="new1">
          <h6>Enter the User-Name</h6>
          <input type="text" placeholder="Username" /><br/><br/>
          <h6>Enter the Password</h6>
          <input type="password" placeholder="Password"/><br></br><br/>
          <input type="button" className="btn btn-success"  value="Submit" /><br/>
          </div>

          </div>
         
      </div>
    )
}
export default LogIn;