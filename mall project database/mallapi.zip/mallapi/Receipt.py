#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type: application/json")

import pymysql
import sys
import os
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,HEAD,DELETE,OPTIONS,")
print("Access-Control-Allow-Headers:Content-Type")
print()


host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def Showall():
    list=[]
    qry="select * from receipt"
    cursor.execute(qry)
    result=cursor.fetchall()
    for i in result:
        dict={
            'rec_id':i[0],
            'rec_date':str(i[1]),
            'cust_phno':i[2],
            'rec_amt':i[3]

        }
        list.append(dict)
    json_array=json.dumps(list,indent=4)
    print(json_array)

def GetNewId():
    cursor.execute("select max(rec_id) from receipt")
    result=cursor.fetchall()
    for i in result:
        if i[0]!=None:
            maxid=i[0]
        else:
            maxid=0
    return(maxid+1)

def Insert():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="insert into receipt value(%s,%s,%s,%s)"
    data['rec_id']=GetNewId()
    values=[data['rec_id'],data['rec_date'],data['cust_phno'],data['rec_amt']]
    cursor.execute(qry,values)
    db.commit()
    db.close()
    return(json.dumps(["Recorded Inserted Successfully"]))

def Update():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="update receipt set rec_date=%s,cust_phno=%s,rec_amt=%s where rec_id=%s"
    values=[data['rec_date'],data['cust_phno'],data['rec_amt'],data['rec_id']]
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Updated Successfully"]))

def Delete():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="delete from receipt where rec_id=%s"
    values=[data['rec_id']]
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Deleted Successfully"]))

if request_method=="GET":
    (Showall())
elif request_method=="POST":
    print(Insert())
elif request_method=="PUT":
    print(Update())
elif request_method=="DELETE":
    print(Delete())