#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import sys
import json
import os

print("Access-Control-Allow-Origin: http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,DELETE,HEAD,OPTIONS")
print("Access-Control-Allow-Headers: Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def Showall():
    list=[]
    qry="select * from item"
    cursor.execute(qry)
    result=cursor.fetchall()
    for i in result:
        dict={
            'item_id':i[0],
            'dept_id':i[1],
            'cat_id':i[2],
            'item_nm':i[3],
            'item_UOM':i[4],
            'item_stock':i[5],
            'item_rate':i[6]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=4)
    print(json_array)

def GetNewId():

    cursor.execute("select max(item_id) from item")
    result=cursor.fetchall()
    for i in result:
        if i[0]!=None:
            maxid=i[0]
        else:
            maxid=0
    return(maxid+1)

def Insert():

    data=sys.stdin.read()
    data=json.loads(data)
    qry="insert into item values(%s,%s,%s,%s,%s,%s,%s)"
    data['item_id']=GetNewId()
    values=[data['item_id'],data['dept_id'],data['cat_id'],data['item_nm'],data['item_UOM'],data['item_stock'],data['item_rate']]
    cursor.execute(qry,values)
    db.commit()
    db.close()
    return(json.dumps(["Record Inserted Successfully"]))


def Update():
    data=sys.stdin.read()
    data=json.loads(data)
    values=[data['dept_id'],data['cat_id'],data['item_nm'],data['item_UOM'],data['item_stock'],data['item_rate'],data['item_id']]
    qry="update item set dept_id=%s,cat_id=%s,item_nm=%s,item_UOM=%s,item_stock=%s,item_rate=%s where item_id=%s "
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Updated Successfully"]))


def Delete():
    data=sys.stdin.read()
    data=json.loads(data)
    values=[data['item_id']]
    qry="delete from item where item_id=%s"
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Deleted Successfully"]))

if request_method=="GET":
    (Showall())
elif request_method=="POST":
    print(Insert())
elif request_method=="PUT":
    print(Update())
elif request_method=="DELETE":
    print(Delete())