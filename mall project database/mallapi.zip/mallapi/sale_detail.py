#!  C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import sys
import os
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,HEAD,POST,DELETE,OPTIONS")
print("Access-Control-Allow-Headers:Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def Showall():
    list=[]
    qry="select * from sale_detail"
    cursor.execute(qry)
    result=cursor.fetchall()
    for i in result:
        dict={
            'sale_det_id':i[0],
            'sale_id':i[1],
            'item_id':i[2],
            'item_rate':i[3],
            'item_qty':i[4],
            'item_amt':i[5]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

def GetNewId():
    cursor.execute("select max(sale_det_id) from sale_detail")
    result=cursor.fetchall()
    for i in result:
        if i[0]!=None:
            maxid=i[0]
        else:
            maxid=0
    return(maxid+1)

def Insert():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="insert into sale_detail values(%s,%s,%s,%s,%s,%s)"
    data['sale_det_id']=GetNewId()
    values=[data['sale_det_id'],data['sale_id'],data['item_id'],data['item_rate'],data['item_qty'],data['item_amt']]
    cursor.execute(qry,values)
    db.commit()

    qry = "update item set item_stock=item_stock-%s where item_id=%s "
    values = [data['item_qty'], data['item_id']]
    cursor.execute(qry, values)
    db.commit()
    db.close()
    return(json.dumps(["Record Inserted Successfully"]))

def Update():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="update sale_detail set sale_id=%s,item_id=%s,item_rate=%s,item_qty=%s,item_amt=%s where sale_det_id=%s"
    values=[data['sale_id'],data['item_id'],data['item_rate'],data['item_qty'],data['item_amt'],data['sale_det_id']]
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Updated Successfully"]))

def Delete():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="delete from sale_detail where sale_det_id=%s"
    values=[data['sale_det_id']]
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record  Deleted Successfully"]))

if request_method=="GET":
    (Showall())
elif request_method=="POST":
    print(Insert())
elif request_method=="PUT":
    print(Update())
elif request_method=="DELETE":
    print(Delete())