#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type: application/json")

import pymysql
import sys
import os
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,HEAD,DELETE,OPTIONS,")
print("Access-Control-Allow-Headers:Content-Type")
print()


host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def Showall():
    list=[]
    qry="select * from sale_master"
    cursor.execute(qry)
    result=cursor.fetchall()
    for i in result:
        dict={
            'sale_id':i[0],
            'counter_id':i[1],
            'emp_id':i[2],
            'sale_date':str(i[3]),
            'gst':i[4],
            'grand_total':i[5]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

def GetNewId():
    cursor.execute("select max(sale_id) from sale_master")
    result=cursor.fetchall()
    for i in result:
        if i[0]!=None:
            maxid=i[0]
        else:
            maxid=0
    return(maxid+1)

def Insert():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="insert into sale_master values(%s,%s,%s,%s,%s,%s)"
    data['sale_id']=GetNewId()
    values=[data['sale_id'],data['counter_id'],data['emp_id'],data['sale_date'],data['gst'],data['grand_total']]
    cursor.execute(qry,values)
    db.commit()
    db.close()
    return(json.dumps(["Record Inserted Successfully"]))

def Update():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="update sale_master set counter_id=%s,emp_id=%s,sale_date=%s,gst=%s,grand_total=%s where sale_id=%s"
    values=[data['counter_id'],data['emp_id'],data['sale_date'],data['gst'],data['grand_total'],data['sale_id']]
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Updated Successfully"]))

def Delete():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="delete from sale_master where sale_id=%s"
    values=[data['sale_id']]
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record  Deleted Successfully"]))

if request_method=="GET":
    (Showall())
elif request_method=="POST":
    print(Insert())
elif request_method=="PUT":
    print(Update())
elif request_method=="DELETE":
    print(Delete())
