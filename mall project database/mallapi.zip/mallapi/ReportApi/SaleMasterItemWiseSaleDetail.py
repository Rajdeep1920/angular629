#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import os
import sys
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,HEAD,DELETE,OPTIONS")
print("Access-Control-Allow-Headers:Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def Showall():
    list=[]
    data = sys.stdin.read()
    data = json.loads(data)
    qry="select sale_det_id,sale_id,item_nm,sale_detail.item_rate,item_qty,item_amt from sale_detail,item where sale_detail.item_id = item.item_id and item.item_id=%s"
    values = [data['item_id']]
    cursor.execute(qry,values)
    result=cursor.fetchall()
    for i in result:
        dict={
            'sale_det_id':i[0],
            'sale_id':i[1],
            'item_id':i[2],
            'item_rate':i[3],
            'item_qty':i[4],
            'item_amt':i[5]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

# def SaleMasterItemWiseSaleDetail():
#     list=[]
#     data=sys.stdin.read()
#     data=json.loads(data)
#     qry="select * from sale_detail where  item_id=%s"
#     values=[data['item_id']]
#     cursor.execute(qry,values)
#     result=cursor.fetchall()
#     for i in result:
#         dict={
#             'sale_det_id': i[0],
#             'sale_id': i[1],
#             'item_id': i[2],
#             'item_rate': i[3],
#             'item_qty': i[4],
#             'item_amt': i[5]
#         }
#         list.append(dict)
#     json_array=json.dumps(list,indent=5)
#     print(json_array)

if request_method=="POST":
    Showall()