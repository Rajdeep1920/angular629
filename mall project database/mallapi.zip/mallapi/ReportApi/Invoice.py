#!  C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe

print("Content-Type: application/json")  # Set the content type

import pymysql
import json
import sys
import os

print("Access-Control-Allow-Origin: http://localhost:3000")  # Allow requests from this origin
print("Access-Control-Allow-Headers: Content-Type")  # Allow the Content-Type header
print("Access-Control-Allow-Methods:GET,DELETE,HEAD,PUT,OPTIONS ")  # Allow the Content-Type header

# Print a blank line to indicate the end of headers
print()

host='localhost'
user='root'
password=''
database = 'malldb'
db = pymysql.connect(host=host, user=user, password=password, db=database)
cursor=db.cursor()
request_method=os.environ["REQUEST_METHOD"]

def Invoice():
    list=[]
    data=sys.stdin.read()
    data=json.loads(data)
    query = ("SELECT item_nm, item_UOM,item_stock,counter_nm,sale_date,gst,grand_total,"
             "sale_detail.item_rate,item_qty,item_amt "
             "from item,counter,sale_master,sale_detail "
             "where item.item_id=sale_detail.item_id and sale_master.sale_id=sale_detail.sale_id and counter.counter_id=sale_master.counter_id and sale_detail.sale_id=%s"
             )
    values=[data['sale_id']]

    # query = ("Select item_nm,item_UOM,item_stock,counter_nm,sale_date,gst,grand_total,item_rate,item_qty,item_amt"
    #          "from item,counter,sale_master,sale_detail"
    #          "where item.item_id=sale_detail.item_id and counter.counter_id=sale_master.counter_id and sale_master.sale_id=sale_detail.sale_id"
    #          "and sale_master.sale_id=%s")

    cursor.execute(query,values)
    result = cursor.fetchall()
    for item in result:
        dict={

            'item_nm': item[0],
            'item_UOM': item[1],
            'item_stock': item[2],
            'counter_nm': item[3],
            'sale_date': str(item[4]),
            'gst': item[5],
            'grand_total': item[6],
            'item_rate': item[7],
            'item_qty': item[8],
            'item_amt': item[9]


        }
        list.append(dict)
    json_array= json.dumps(list,indent=4)
    print(json_array)

if request_method == 'POST':
    Invoice()






# #!  C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
# print("Content-Type:application/json")
#
# import pymysql
# import sys
# import os
# import json
#
# print("Access-Control-Allow-Origin:http://localhost:3000")
# print("Access-Control-Allow-Methods:GET,PUT,HEAD,POST,DELETE,OPTIONS")
# print("Access-Control-Allow-Headers:Content-Type")
# print()
#
# host='localhost'
# user='root'
# password=''
# database='malldb'
#
# db=pymysql.connect(host=host,user=user,password=password,db=database)
# cursor=db.cursor()
#
# request_method=os.environ["REQUEST_METHOD"]
#
# def Invoice():
#     list=[]
#     data=sys.stdin.read()
#     data=json.loads(data)
#     qry=("select item_nm,item_UOM,item_stock,counter_nm,sale_date,gst,grand_total,item_rate,item_qty,item_amt "
#          "from item,counter,sale_master,sale_detail"
#          " where item.item_id=sale_detail.item_id and counter.counter_id=sale_master.counter_id "
#          "and sale_master.sale_id=sale_detail.sale_id "
#          "and sale_master.sale_id=%s")
#     values=[data['sale_id']]
#     cursor.execute(qry,values)
#     result=cursor.fetchall()
#     for i in result:
#         dict={
#             'item_nm':i[0],
#             'item_UOM': i[1],
#             'item_stock': i[2],
#             'counter_nm': i[3],
#             'sale_date': str(i[4]),
#             'gst': i[5],
#             'grand_total': i[6],
#             'item_rate': i[7],
#             'item_qty': i[8],
#             'item_amt': i[9]
#         }
#         list.append(dict)
#     json_array=json.dumps(list,indent=4)
#     print(json_array)
#
# if request_method=="POST":
#     (Invoice())


