#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe"
print("Content-Type:application/json")

import pymysql
import sys
import os
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,POST,HEAD,PUT,DELETE,OPTIONS")
print("Access-Control-Allow-Headers:Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

# def ShowAll():
#     list=[]
#     data=sys.stdin.read()
#     data=json.loads(data)
#     qry="select item_id,dept_id,cat_id,item_nm,item_UOM,item_stock from item,department,item_category where item.dept_id=department.dept_id and item.cat_id=item_category.cat_id"
#     values=[data['item_id'],data['dept_id'],data['cat_id'],data['item_nm'],data['item_UOM'],data['item_stock']]
#     cursor.execute(qry,values)
#     result=cursor.fetchall()
#     for i in result:
#         dict={
#             'item_id':i[0],
#             'dept_id':i[1],
#             'cat_id':i[2],
#             'item_nm':i[3],
#             'item_UOM':i[4],
#             'item_stock':i[5]
#         }
#         list.append(dict)
#     json_array=json.dumps(list,indent=5)
#     print(json_array)

def DepItemWiseItem():
    list=[]
    data=sys.stdin.read()
    data=json.loads(data)
    qry = "select item_id,dept_nm,cat_nm,item_nm,item_UOM,item_stock from item,department,item_category where item.dept_id=department.dept_id and item.cat_id=item_category.cat_id and department.dept_id=%s and item_category.cat_id=%s"
    values=[data['dept_id'],data['cat_id']]
    cursor.execute(qry,values)
    result=cursor.fetchall()
    for i in result:
        dict={
            'item_id': i[0],
            'dept_id': i[1],
            'cat_id': i[2],
            'item_nm': i[3],
            'item_UOM': i[4],
            'item_stock': i[5]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

# if request_method=="GET":
#     (ShowAll())
if request_method=="POST":
    (DepItemWiseItem())