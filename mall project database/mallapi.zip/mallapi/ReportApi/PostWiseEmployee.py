#!  C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe

print("Content-Type: application/json")  # Set the content type

import pymysql
import json
import sys
import os

print("Access-Control-Allow-Origin: http://localhost:3000")  # Allow requests from this origin
print("Access-Control-Allow-Headers: Content-Type")  # Allow the Content-Type header
print("Access-Control-Allow-Methods:GET,DELETE,HEAD,PUT,OPTIONS ")  # Allow the Content-Type header

# Print a blank line to indicate the end of headers
print()

host='localhost'
user='root'
password=''
database = 'malldb'
db = pymysql.connect(host=host, user=user, password=password, db=database)
cursor=db.cursor()
request_method=os.environ["REQUEST_METHOD"]

# def showall():
#     list=[]
#     data=sys.stdin.read()
#     data=json.dumps(data)
#     qry="select emp_id,post_id,shift_nm,emp_nm,emp_addr,emp_phno,emp_mail,emp_salary,emp_DOB,emp_DOJ from employee,post where employee.post_id=post.post_id"
#     values=[data['emp_id'],data['post_id'],data['shift_nm'],data['emp_nm'],data['emp_addr'],data['emp_phno'],data['emp_mail'],data['emp_salary'],data['emp_DOB'],data['emp_DOJ']]
#     cursor.execute(qry,values)
#     result=cursor.fetchall()
#     for i in result:
#         dict={
#             'emp_id':i[0],
#             'post_id':i[1],
#             'shift_nm':i[2],
#             'emp_nm':i[3],
#             'emp_addr':i[4],
#             'emp_phno':i[5],
#             'emp_mail':i[6],
#             'emp_salary':i[7],
#             'emp_DOB':str(i[8]),
#             'emp_DOJ':str(i[9])
#         }
#         list.append(dict)
#     json_array=json.dumps(list,indent=5)
#     print(json_array)

def PostWiseEmployee():
    list=[]
    data=sys.stdin.read()
    data=json.loads(data)
    qry="select emp_id,post_nm,shift_nm,emp_nm,emp_addr,emp_phno,emp_mail,emp_salary,emp_DOB,emp_DOJ from employee,post where employee.post_id=post.post_id and post.post_id=%s"
    values=[data['post_id']]
    cursor.execute(qry,values)
    result=cursor.fetchall()
    for i in result:
        dict={
            'emp_id': i[0],
            'post_id': i[1],
            'shift_nm': i[2],
            'emp_nm': i[3],
            'emp_addr': i[4],
            'emp_phno': i[5],
            'emp_mail': i[6],
            'emp_salary': i[7],
            'emp_DOB': str(i[8]),
            'emp_DOJ': str(i[9])
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

# if request_method=="GET":
#     (showall())
if request_method=="POST":
    (PostWiseEmployee())