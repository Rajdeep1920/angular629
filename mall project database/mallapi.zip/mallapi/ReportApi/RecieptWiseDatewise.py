#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import os
import sys
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,HEAD,DELETE,OPTIONS")
print("Access-Control-Allow-Headers:Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def ReceiptDatewise():
    list=[]
    data=sys.stdin.read()
    data=json.loads(data)
    qry="select * from receipt where rec_date between %s and %s"
    values=[data['fromdate'],data['todate']]
    cursor.execute(qry,values)
    result=cursor.fetchall()
    for i in result:
        dict={
            'rec_id':i[0],
            'rec_date':str(i[1]),
            'cust_id':i[2],
            'rec_amt':i[3]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

if request_method=="POST":
    ReceiptDatewise()
