#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import os
import sys
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,HEAD,DELETE,OPTIONS")
print("Access-Control-Allow-Headers:Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()


request_method=os.environ["REQUEST_METHOD"]


def SaleDetFetchItemRate():
    list=[]
    data=sys.stdin.read()
    data=json.loads(data)
    qry="select item_rate,item_stock from item where item.item_rate and item.item_stock and item.item_id=%s"
    values = [data['item_id']]
    # data['sale_det_id']=GetNewId()
    cursor.execute(qry,values)
    result=cursor.fetchall()
    for i in result:
        dict={

            'item_rate':i[0],
            'item_stock':i[1]


        }
        list.append(dict)
    json_array=json.dumps(list,indent=4)
    print(json_array)

if request_method=="POST":
    (SaleDetFetchItemRate())
