#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import os
import sys
import json

print("Access-Control-Allow-Origin:http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,HEAD,DELETE,OPTIONS")
print("Access-Control-Allow-Headers:Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

# def Showall():
#     list=[]
#     qry="select cat_id,dept_id,cat_nm from item_category,department where item_category.dept_id=department.dept_id"
#     cursor.execute(qry)
#     result=cursor.fetchall()
#     for i in result:
#         dict={
#             'cat_id':i[0],
#             'dept_id':i[1],
#             'cat_nm':i[2]
#         }
#         list.append(dict)
#     json_array=json.dumps(list,indent=5)
#     print(json_array)


def DepartmentWiseItemCategory():
    list=[]
    data=sys.stdin.read()
    data=json.loads(data)
    qry = "select cat_id,dept_nm,cat_nm from item_category,department where item_category.dept_id=department.dept_id and department.dept_id=%s"
    values=[data['dept_id']]
    cursor.execute(qry,values)
    result=cursor.fetchall()
    for i in result:
        dict={
            'cat_id':i[0],
            'dept_id':i[1],
            'cat_nm':i[2]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=5)
    print(json_array)

# if request_method=="GET":
#     (Showall())
if request_method=="POST":
    (DepartmentWiseItemCategory())