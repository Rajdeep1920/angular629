#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import sys
import json
import os

print("Access-Control-Allow-Origin: http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,DELETE,HEAD,OPTIONS")
print("Access-Control-Allow-Headers: Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]

def Showall():
    list=[]
    qry="select * from counter"
    cursor.execute(qry)
    result=cursor.fetchall()
    for i in result:
        dict={
            'counter_id':i[0],
            'counter_nm':i[1]
        }
        list.append(dict)
    json_array=json.dumps(list,indent=4)
    print(json_array)

def GetNewID():
    cursor.execute("select max(counter_id) from counter")
    records=cursor.fetchall()
    for i in records:
        if i[0]!=None:
            maxid=i[0]
        else:
            maxid=0

    return(maxid+1)

def Insert():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="insert into counter values(%s,%s)"
    data['counter_id']=GetNewID()
    values=[data['counter_id'],data['counter_nm']]
    cursor.execute(qry,values)
    db.commit()
    db.close()
    return(json.dumps(["Record Inserted Successfully"]))

def Update():
    data=sys.stdin.read()
    data=json.loads(data)
    values=[data['counter_nm'],data['counter_id']]
    qry="update counter set counter_nm=%s where counter_id=%s"
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Updated Successfully"]))

def Delete():
    data=sys.stdin.read()
    data=json.loads(data)
    values=[data['counter_id']]
    qry="delete from counter where counter_id=%s"
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Deleted Successfully"]))

if request_method=="GET":
    (Showall())
elif request_method=="POST":
    print(Insert())
elif request_method=="PUT":
    print(Update())
elif request_method=="DELETE":
    print(Delete())








