#! C:\xmpp\htdocs\mallapi\venv\Scripts\python.exe
print("Content-Type:application/json")

import pymysql
import sys
import json
import os

print("Access-Control-Allow-Origin: http://localhost:3000")
print("Access-Control-Allow-Methods:GET,PUT,POST,DELETE,HEAD,OPTIONS")
print("Access-Control-Allow-Headers: Content-Type")
print()

host='localhost'
user='root'
password=''
database='malldb'

db=pymysql.connect(host=host,user=user,password=password,db=database)
cursor=db.cursor()

request_method=os.environ["REQUEST_METHOD"]


def Showall():
    list=[]
    qry="select * from employee"
    cursor.execute(qry)
    result=cursor.fetchall()
    for i in result:
        dict={
            'emp_id':i[0],
            'post_id':i[1],
            'shift_nm':i[2],
            'emp_nm':i[3],
            'emp_addr':i[4],
            'emp_phno':i[5],
            'emp_mail':i[6],
            'emp_salary':i[7],
            'emp_DOB':str(i[8]),
            'emp_DOJ':str(i[9])
        }
        list.append(dict)
    json_array=json.dumps(list,indent=4)
    print(json_array)

def GetNewId():
    cursor.execute("select max(emp_id) from employee")
    result=cursor.fetchall()
    for i in result:
        if i[0]!=None:
            maxid=i[0]
        else:
            maxid=0
    return(maxid+1)

def Insert():
    data=sys.stdin.read()
    data=json.loads(data)
    qry="insert into employee values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    data['emp_id']=GetNewId()
    values=[data['emp_id'],data['post_id'],data['shift_nm'],data['emp_nm'],data['emp_addr'],data['emp_phno'],data['emp_mail'],data['emp_salary'],data['emp_DOB'],data['emp_DOJ']]
    cursor.execute(qry,values)
    db.commit()
    db.close()
    return(json.dumps(["Record Inserted Successfully"]))

def Update():
    data=sys.stdin.read()
    data=json.loads(data)
    values=[data['post_id'],data['shift_nm'],data['emp_nm'],data['emp_addr'],data['emp_phno'],data['emp_mail'],data['emp_salary'],data['emp_DOB'],data['emp_DOJ'],data['emp_id']]
    qry="update employee set post_id=%s, shift_nm=%s, emp_nm=%s, emp_addr=%s, emp_phno=%s, emp_mail=%s, emp_salary=%s, emp_DOB=%s, emp_DOJ=%s where emp_id=%s"
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Updated Successfully"]))

def Delete():
    data=sys.stdin.read()
    data=json.loads(data)
    values=[data['emp_id']]
    qry="delete from employee where emp_id=%s"
    cursor.execute(qry,values)
    db.commit()
    return(json.dumps(["Record Deleted Successfully"]))

if request_method=="GET":
    (Showall())
elif request_method=="POST":
    print(Insert())
elif request_method=="PUT":
    print(Update())
elif request_method=="DELETE":
    print(Delete())
